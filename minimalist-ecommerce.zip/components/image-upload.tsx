"use client"

import { useState, useCallback } from "react"
import { useDropzone } from "react-dropzone"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Upload, X, ImageIcon } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface ImageUploadProps {
  value: string
  onChange: (url: string) => void
  onRemove: () => void
  disabled?: boolean
}

export function ImageUpload({ value, onChange, onRemove, disabled }: ImageUploadProps) {
  const [isUploading, setIsUploading] = useState(false)
  const { toast } = useToast()

  const onDrop = useCallback(
    async (acceptedFiles: File[]) => {
      if (acceptedFiles.length === 0) return

      const file = acceptedFiles[0]

      // Validate file type
      if (!file.type.startsWith("image/")) {
        toast({
          title: "Invalid file type",
          description: "Please upload an image file",
          variant: "destructive",
        })
        return
      }

      // Validate file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "File too large",
          description: "Please upload an image smaller than 5MB",
          variant: "destructive",
        })
        return
      }

      setIsUploading(true)

      try {
        // Convert file to base64 for demo purposes
        // In production, you would upload to a cloud storage service
        const reader = new FileReader()
        reader.onload = (e) => {
          const result = e.target?.result as string
          onChange(result)
          setIsUploading(false)
          toast({
            title: "Image uploaded successfully",
            description: "Your product image has been uploaded",
          })
        }
        reader.onerror = () => {
          setIsUploading(false)
          toast({
            title: "Upload failed",
            description: "Failed to upload image. Please try again.",
            variant: "destructive",
          })
        }
        reader.readAsDataURL(file)
      } catch (error) {
        setIsUploading(false)
        toast({
          title: "Upload failed",
          description: "Failed to upload image. Please try again.",
          variant: "destructive",
        })
      }
    },
    [onChange, toast],
  )

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      "image/*": [".jpeg", ".jpg", ".png", ".gif", ".webp"],
    },
    maxFiles: 1,
    disabled: disabled || isUploading,
  })

  return (
    <div className="space-y-4">
      {value ? (
        <Card className="relative">
          <CardContent className="p-4">
            <div className="relative aspect-square max-w-xs mx-auto">
              <img
                src={value || "/placeholder.svg"}
                alt="Product image"
                className="w-full h-full object-cover rounded-lg"
              />
              <Button
                type="button"
                onClick={onRemove}
                variant="destructive"
                size="icon"
                className="absolute top-2 right-2"
                disabled={disabled}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card
          {...getRootProps()}
          className={`border-2 border-dashed cursor-pointer transition-colors ${
            isDragActive ? "border-blue-500 bg-blue-50" : "border-gray-300 hover:border-gray-400"
          } ${disabled ? "cursor-not-allowed opacity-50" : ""}`}
        >
          <CardContent className="p-8">
            <input {...getInputProps()} />
            <div className="text-center">
              {isUploading ? (
                <div className="space-y-2">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mx-auto"></div>
                  <p className="text-sm text-gray-600">Uploading image...</p>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="mx-auto w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center">
                    {isDragActive ? (
                      <Upload className="h-8 w-8 text-blue-500" />
                    ) : (
                      <ImageIcon className="h-8 w-8 text-gray-400" />
                    )}
                  </div>
                  <div>
                    <p className="text-lg font-medium">
                      {isDragActive ? "Drop your image here" : "Upload product image"}
                    </p>
                    <p className="text-sm text-gray-600">Drag and drop an image, or click to browse</p>
                    <p className="text-xs text-gray-500 mt-2">Supports: JPEG, PNG, GIF, WebP (max 5MB)</p>
                  </div>
                  <Button type="button" variant="outline" disabled={disabled}>
                    <Upload className="mr-2 h-4 w-4" />
                    Choose Image
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
