"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star, ShoppingCart } from "lucide-react"
import Link from "next/link"

interface Product {
  id: string
  name: string
  price: number
  originalPrice?: number
  image: string
  rating?: number
  reviews?: number
  badge?: string
  category: string
}

interface RelatedProductsProps {
  products: Product[]
}

export function RelatedProducts({ products }: RelatedProductsProps) {
  if (!products || products.length === 0) {
    return null
  }

  return (
    <div className="mt-16">
      <h2 className="text-2xl font-bold text-black mb-8">Related Products</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {products.map((product) => (
          <Card key={product.id} className="border-2 border-gray-200 hover:border-black transition-colors">
            <div className="relative">
              <Link href={`/product/${product.id}`}>
                <img
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  className="w-full h-48 object-cover rounded-t-lg hover:opacity-90 transition-opacity cursor-pointer"
                />
              </Link>
              {product.badge && (
                <Badge className="absolute top-2 left-2 bg-black text-white text-xs">{product.badge}</Badge>
              )}
            </div>
            <CardContent className="p-4">
              <Link href={`/product/${product.id}`}>
                <h3 className="font-bold text-black mb-2 hover:text-gray-700 cursor-pointer line-clamp-2">
                  {product.name}
                </h3>
              </Link>

              {product.rating && (
                <div className="flex items-center gap-1 mb-2">
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-3 h-3 ${
                          i < Math.floor(product.rating!) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-xs text-gray-600">({product.reviews})</span>
                </div>
              )}

              <div className="flex items-center gap-2 mb-3">
                <span className="font-bold text-black">R{product.price}</span>
                {product.originalPrice && (
                  <span className="text-sm text-gray-500 line-through">R{product.originalPrice}</span>
                )}
              </div>

              <Button asChild size="sm" className="w-full bg-black hover:bg-gray-800 text-white">
                <Link href={`/product/${product.id}`}>
                  <ShoppingCart className="mr-2 h-3 w-3" />
                  View Product
                </Link>
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
