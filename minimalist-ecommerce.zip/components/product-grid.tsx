"use client"

import type React from "react"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useCart } from "@/components/cart-provider"
import { useToast } from "@/hooks/use-toast"
import { TrendingUp, Palette, Star } from "lucide-react"
import Link from "next/link"

interface Product {
  id: string
  name: string
  price: number
  category: string
  image: string
  description: string
  trendScore?: number
  isPrintOnDemand?: boolean
  reviews?: Array<{
    rating: number
  }>
}

interface ProductGridProps {
  products: Product[]
}

export function ProductGrid({ products }: ProductGridProps) {
  const { addItem } = useCart()
  const { toast } = useToast()

  const handleAddToCart = (product: Product, e: React.MouseEvent) => {
    e.preventDefault() // Prevent navigation to product page
    e.stopPropagation()

    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      category: product.category,
    })
    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart.`,
    })
  }

  const calculateAverageRating = (reviews: any[]) => {
    if (!reviews || reviews.length === 0) return 0
    return reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
      {products.map((product) => {
        const averageRating = calculateAverageRating(product.reviews || [])

        return (
          <Link key={product.id} href={`/product/${product.id}`}>
            <Card className="group border-2 border-gray-200 hover:border-black transition-all duration-300 cursor-pointer">
              <CardContent className="p-0">
                <div className="aspect-square bg-gray-100 relative overflow-hidden">
                  <img
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />

                  {/* Badges */}
                  <div className="absolute top-3 left-3 flex flex-col space-y-2">
                    {product.trendScore && product.trendScore > 80 && (
                      <Badge className="bg-red-500 text-white">
                        <TrendingUp className="w-3 h-3 mr-1" />
                        Trending
                      </Badge>
                    )}
                    {product.isPrintOnDemand && (
                      <Badge className="bg-purple-500 text-white">
                        <Palette className="w-3 h-3 mr-1" />
                        Customizable
                      </Badge>
                    )}
                  </div>

                  {/* Quick Add Button */}
                  <div className="absolute bottom-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <Button
                      onClick={(e) => handleAddToCart(product, e)}
                      size="sm"
                      className="bg-black text-white hover:bg-gray-800"
                    >
                      Quick Add
                    </Button>
                  </div>
                </div>

                <div className="p-6">
                  <div className="mb-4">
                    <h3 className="text-xl font-bold text-black mb-2 group-hover:text-gray-700 transition-colors">
                      {product.name}
                    </h3>
                    <p className="text-gray-600 text-sm mb-3 line-clamp-2">{product.description}</p>

                    {/* Rating */}
                    {product.reviews && product.reviews.length > 0 && (
                      <div className="flex items-center space-x-1 mb-2">
                        <div className="flex items-center">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-3 h-3 ${
                                i < Math.floor(averageRating) ? "text-yellow-400 fill-current" : "text-gray-300"
                              }`}
                            />
                          ))}
                        </div>
                        <span className="text-xs text-gray-500">({product.reviews.length})</span>
                      </div>
                    )}

                    <div className="flex items-center justify-between">
                      <p className="text-2xl font-bold text-black">R{product.price}</p>
                      <span className="text-sm text-gray-500 capitalize">{product.category.replace("-", " ")}</span>
                    </div>
                  </div>

                  <Button
                    onClick={(e) => handleAddToCart(product, e)}
                    className="w-full bg-black text-white hover:bg-gray-800"
                  >
                    Add to Cart
                  </Button>
                </div>
              </CardContent>
            </Card>
          </Link>
        )
      })}
    </div>
  )
}
