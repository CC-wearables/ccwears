"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Palette, Type, ImageIcon } from "lucide-react"
import { getCanvaClient } from "@/lib/canva-api"

interface BrandKit {
  colors: string[]
  fonts: string[]
  logos: Array<{
    id: string
    name: string
    url: string
  }>
}

interface CanvaBrandKitProps {
  onColorSelect: (color: string) => void
  onFontSelect: (font: string) => void
  onLogoSelect: (logo: string) => void
}

export function CanvaBrandKit({ onColorSelect, onFontSelect, onLogoSelect }: CanvaBrandKitProps) {
  const [brandKit, setBrandKit] = useState<BrandKit | null>(null)
  const [loading, setLoading] = useState(true)

  const canvaClient = getCanvaClient()

  useEffect(() => {
    loadBrandKit()
  }, [])

  const loadBrandKit = async () => {
    try {
      setLoading(true)
      const kit = await canvaClient.getBrandKit()
      setBrandKit(kit)
    } catch (error) {
      console.error("Error loading brand kit:", error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <Card className="border-2 border-blue-500">
        <CardHeader>
          <CardTitle>Loading Brand Kit...</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-4">
            <div className="flex space-x-2">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="w-8 h-8 bg-gray-200 rounded-full"></div>
              ))}
            </div>
            <div className="space-y-2">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="h-4 bg-gray-200 rounded"></div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (!brandKit) return null

  return (
    <Card className="border-2 border-blue-500">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center">
            <Palette className="w-5 h-5 mr-2" />
            Brand Kit
          </CardTitle>
          <Badge variant="secondary">CC Wearables</Badge>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Brand Colors */}
        <div>
          <h4 className="font-medium mb-3 flex items-center">
            <Palette className="w-4 h-4 mr-2" />
            Brand Colors
          </h4>
          <div className="flex flex-wrap gap-2">
            {brandKit.colors.map((color, index) => (
              <button
                key={index}
                className="w-10 h-10 rounded-lg border-2 border-gray-300 hover:border-gray-500 transition-colors shadow-sm"
                style={{ backgroundColor: color }}
                onClick={() => onColorSelect(color)}
                title={color}
              />
            ))}
          </div>
        </div>

        {/* Brand Fonts */}
        <div>
          <h4 className="font-medium mb-3 flex items-center">
            <Type className="w-4 h-4 mr-2" />
            Brand Fonts
          </h4>
          <div className="space-y-2">
            {brandKit.fonts.map((font, index) => (
              <Button
                key={index}
                variant="outline"
                className="w-full justify-start text-left bg-transparent"
                style={{ fontFamily: font }}
                onClick={() => onFontSelect(font)}
              >
                {font} - The quick brown fox jumps
              </Button>
            ))}
          </div>
        </div>

        {/* Brand Logos */}
        <div>
          <h4 className="font-medium mb-3 flex items-center">
            <ImageIcon className="w-4 h-4 mr-2" />
            Brand Logos
          </h4>
          <div className="grid grid-cols-2 gap-3">
            {brandKit.logos.map((logo) => (
              <Card
                key={logo.id}
                className="cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => onLogoSelect(logo.url)}
              >
                <CardContent className="p-3 text-center">
                  <img
                    src={logo.url || "/placeholder.svg"}
                    alt={logo.name}
                    className="w-full h-16 object-contain mb-2"
                  />
                  <p className="text-xs font-medium">{logo.name}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Brand Kit Info */}
        <div className="p-3 bg-blue-50 rounded-lg">
          <p className="text-sm text-blue-800">
            <strong>Brand Kit:</strong> Maintain consistent branding across all your designs with your custom colors,
            fonts, and logos.
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
