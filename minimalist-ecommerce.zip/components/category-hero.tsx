interface CategoryHeroProps {
  title: string
  description: string
  image: string
}

export function CategoryHero({ title, description, image }: CategoryHeroProps) {
  return (
    <section className="relative bg-black text-white py-20">
      <div className="absolute inset-0 opacity-30">
        <img src={image || "/placeholder.svg"} alt={title} className="w-full h-full object-cover" />
      </div>
      <div className="relative container mx-auto px-4 text-center">
        <h1 className="text-5xl font-bold mb-6">{title}</h1>
        <p className="text-xl text-gray-300 max-w-2xl mx-auto">{description}</p>
      </div>
    </section>
  )
}
