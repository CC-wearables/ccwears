import Link from "next/link"

export function Footer() {
  return (
    <footer className="bg-black text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <img src="/cc-wearables-logo.jpg" alt="CC Wearables" className="h-8 w-auto" />
            </div>
            <p className="text-gray-400">Premium wearable technology and fashion at ccwearables.com</p>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Shop</h4>
            <ul className="space-y-2 text-gray-400">
              <li>
                <Link href="/catalog/electronics" className="hover:text-white">
                  Electronics
                </Link>
              </li>
              <li>
                <Link href="/catalog/clothing" className="hover:text-white">
                  Clothing
                </Link>
              </li>
              <li>
                <Link href="/catalog/print-on-demand" className="hover:text-white">
                  Print on Demand
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Support</h4>
            <ul className="space-y-2 text-gray-400">
              <li>
                <Link href="/policies" className="hover:text-white">
                  Policies
                </Link>
              </li>
              <li>
                <Link href="/policies#shipping" className="hover:text-white">
                  Shipping
                </Link>
              </li>
              <li>
                <Link href="/policies#returns" className="hover:text-white">
                  Returns
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-white">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Account</h4>
            <ul className="space-y-2 text-gray-400">
              <li>
                <Link href="/auth/signin" className="hover:text-white">
                  Sign In
                </Link>
              </li>
              <li>
                <Link href="/auth/signup" className="hover:text-white">
                  Sign Up
                </Link>
              </li>
              <li>
                <Link href="/admin" className="hover:text-white">
                  Admin
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; 2024 Minimal Store. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
