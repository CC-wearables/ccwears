"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, Crown, ExternalLink, Download } from "lucide-react"
import { getCanvaClient, type CanvaTemplate, type CanvaAsset } from "@/lib/canva-api"
import { useToast } from "@/hooks/use-toast"

interface CanvaTemplateBrowserProps {
  onTemplateSelect: (template: CanvaTemplate) => void
  onAssetSelect: (asset: CanvaAsset) => void
  category?: string
}

export function CanvaTemplateBrowser({ onTemplateSelect, onAssetSelect, category }: CanvaTemplateBrowserProps) {
  const [templates, setTemplates] = useState<CanvaTemplate[]>([])
  const [assets, setAssets] = useState<CanvaAsset[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState("templates")
  const { toast } = useToast()

  const canvaClient = getCanvaClient()

  useEffect(() => {
    loadTemplates()
    loadAssets()
  }, [category])

  const loadTemplates = async () => {
    try {
      setLoading(true)
      const templateData = await canvaClient.getTemplates(category, 20)
      setTemplates(templateData)
    } catch (error) {
      toast({
        title: "Error loading templates",
        description: "Using demo templates for now",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const loadAssets = async () => {
    try {
      const [photos, elements] = await Promise.all([
        canvaClient.getPremiumAssets("photos"),
        canvaClient.getPremiumAssets("elements"),
      ])
      setAssets([...photos, ...elements])
    } catch (error) {
      console.error("Error loading assets:", error)
    }
  }

  const handleTemplateSelect = async (template: CanvaTemplate) => {
    try {
      const design = await canvaClient.createDesignFromTemplate(template.id, `Custom ${template.name}`)

      toast({
        title: "Template Selected!",
        description: `${template.name} is ready for customization`,
      })

      onTemplateSelect(template)
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load template",
        variant: "destructive",
      })
    }
  }

  const filteredTemplates = templates.filter(
    (template) =>
      template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      template.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase())),
  )

  const filteredAssets = assets.filter(
    (asset) =>
      asset.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      asset.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase())),
  )

  return (
    <Card className="border-2 border-purple-500">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center">
            <img src="https://www.canva.com/favicon.ico" alt="Canva" className="w-6 h-6 mr-2" />
            Canva Pro Library
          </CardTitle>
          <Badge variant="secondary" className="bg-purple-100 text-purple-800">
            <Crown className="w-3 h-3 mr-1" />
            Premium Access
          </Badge>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input
            placeholder="Search templates and assets..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </CardHeader>

      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="templates">Templates ({filteredTemplates.length})</TabsTrigger>
            <TabsTrigger value="assets">Assets ({filteredAssets.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="templates" className="mt-4">
            {loading ? (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="bg-gray-200 aspect-square rounded mb-2"></div>
                    <div className="bg-gray-200 h-4 rounded mb-1"></div>
                    <div className="bg-gray-200 h-3 rounded w-2/3"></div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 max-h-96 overflow-y-auto">
                {filteredTemplates.map((template) => (
                  <Card
                    key={template.id}
                    className="cursor-pointer hover:shadow-lg transition-shadow group"
                    onClick={() => handleTemplateSelect(template)}
                  >
                    <CardContent className="p-3">
                      <div className="relative">
                        <img
                          src={template.thumbnail || "/placeholder.svg"}
                          alt={template.name}
                          className="w-full aspect-square object-cover rounded mb-2"
                        />
                        {template.isPremium && (
                          <Badge className="absolute top-2 right-2 bg-yellow-500 text-white">
                            <Crown className="w-3 h-3 mr-1" />
                            Pro
                          </Badge>
                        )}
                        <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity rounded flex items-center justify-center">
                          <Button size="sm" variant="secondary">
                            <ExternalLink className="w-4 h-4 mr-1" />
                            Use Template
                          </Button>
                        </div>
                      </div>
                      <h4 className="font-medium text-sm mb-1 truncate">{template.name}</h4>
                      <div className="flex flex-wrap gap-1">
                        {template.tags.slice(0, 2).map((tag) => (
                          <Badge key={tag} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="assets" className="mt-4">
            <div className="grid grid-cols-3 md:grid-cols-4 gap-3 max-h-96 overflow-y-auto">
              {filteredAssets.map((asset) => (
                <Card
                  key={asset.id}
                  className="cursor-pointer hover:shadow-lg transition-shadow group"
                  onClick={() => onAssetSelect(asset)}
                >
                  <CardContent className="p-2">
                    <div className="relative">
                      <img
                        src={asset.thumbnail || "/placeholder.svg"}
                        alt={asset.name}
                        className="w-full aspect-square object-cover rounded mb-1"
                      />
                      {asset.isPremium && (
                        <Badge className="absolute top-1 right-1 bg-yellow-500 text-white text-xs">
                          <Crown className="w-2 h-2" />
                        </Badge>
                      )}
                      <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity rounded flex items-center justify-center">
                        <Button size="sm" variant="secondary">
                          <Download className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                    <p className="text-xs font-medium truncate">{asset.name}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        {/* Canva Pro Features */}
        <div className="mt-6 p-4 bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg">
          <h4 className="font-bold text-purple-800 mb-2">🎨 Canva Pro Features Active</h4>
          <div className="grid grid-cols-2 gap-2 text-sm text-purple-700">
            <div className="flex items-center">
              <Crown className="w-4 h-4 mr-1 text-yellow-500" />
              100M+ Premium Templates
            </div>
            <div className="flex items-center">
              <Crown className="w-4 h-4 mr-1 text-yellow-500" />
              Premium Photos & Graphics
            </div>
            <div className="flex items-center">
              <Crown className="w-4 h-4 mr-1 text-yellow-500" />
              AI-Powered Tools
            </div>
            <div className="flex items-center">
              <Crown className="w-4 h-4 mr-1 text-yellow-500" />
              Brand Kit Integration
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
