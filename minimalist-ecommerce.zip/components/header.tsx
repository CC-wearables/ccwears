"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ShoppingCart, User, Menu, Search, TrendingUp } from "lucide-react"
import { useState } from "react"
import { useCart } from "@/components/cart-provider"

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const { items } = useCart()
  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0)

  return (
    <header className="bg-white border-b-2 border-black sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-2">
            <img src="/cc-wearables-logo.jpg" alt="CC Wearables" className="h-10 w-auto" />
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/trending" className="text-black hover:text-gray-600 font-medium flex items-center">
              <TrendingUp className="w-4 h-4 mr-1" />
              Trending
            </Link>
            <Link href="/catalog/electronics" className="text-black hover:text-gray-600 font-medium">
              Electronics
            </Link>
            <Link href="/catalog/clothing" className="text-black hover:text-gray-600 font-medium">
              Clothing
            </Link>
            <Link href="/catalog/print-on-demand" className="text-black hover:text-gray-600 font-medium">
              Print on Demand
            </Link>
            <Link href="/policies" className="text-black hover:text-gray-600 font-medium">
              Policies
            </Link>
          </nav>

          {/* Actions */}
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon" className="hidden md:flex">
              <Search className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" asChild>
              <Link href="/auth/signin">
                <User className="h-5 w-5" />
              </Link>
            </Button>
            <Button variant="ghost" size="icon" className="relative" asChild>
              <Link href="/cart">
                <ShoppingCart className="h-5 w-5" />
                {itemCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-black text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                    {itemCount}
                  </span>
                )}
              </Link>
            </Button>
            <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden border-t border-gray-200 py-4">
            <nav className="flex flex-col space-y-4">
              <Link href="/trending" className="text-black hover:text-gray-600 font-medium flex items-center">
                <TrendingUp className="w-4 h-4 mr-1" />
                Trending
              </Link>
              <Link href="/catalog/electronics" className="text-black hover:text-gray-600 font-medium">
                Electronics
              </Link>
              <Link href="/catalog/clothing" className="text-black hover:text-gray-600 font-medium">
                Clothing
              </Link>
              <Link href="/catalog/print-on-demand" className="text-black hover:text-gray-600 font-medium">
                Print on Demand
              </Link>
              <Link href="/policies" className="text-black hover:text-gray-600 font-medium">
                Policies
              </Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  )
}
