"use client"

// Canva API configuration and utilities
export interface CanvaConfig {
  apiKey: string
  teamId?: string
  brandId?: string
}

export interface CanvaTemplate {
  id: string
  name: string
  thumbnail: string
  category: string
  tags: string[]
  isPremium: boolean
}

export interface CanvaDesign {
  id: string
  name: string
  thumbnail: string
  urls: {
    edit_url: string
    view_url: string
  }
  export_url?: string
}

export interface CanvaAsset {
  id: string
  name: string
  thumbnail: string
  type: "image" | "video" | "audio" | "element"
  isPremium: boolean
  tags: string[]
}

class CanvaAPIClient {
  private apiKey: string
  private baseUrl = "https://api.canva.com/rest/v1"
  private teamId?: string

  constructor(config: CanvaConfig) {
    this.apiKey = config.apiKey
    this.teamId = config.teamId
  }

  private async makeRequest(endpoint: string, options: RequestInit = {}) {
    const url = `${this.baseUrl}${endpoint}`

    const response = await fetch(url, {
      ...options,
      headers: {
        Authorization: `Bearer ${this.apiKey}`,
        "Content-Type": "application/json",
        ...options.headers,
      },
    })

    if (!response.ok) {
      throw new Error(`Canva API error: ${response.status} ${response.statusText}`)
    }

    return response.json()
  }

  // Get available templates
  async getTemplates(category?: string, limit = 20): Promise<CanvaTemplate[]> {
    try {
      const params = new URLSearchParams({
        limit: limit.toString(),
        ...(category && { category }),
      })

      const data = await this.makeRequest(`/templates?${params}`)
      return data.items || []
    } catch (error) {
      console.error("Error fetching templates:", error)
      // Return mock data for demo
      return this.getMockTemplates(category)
    }
  }

  // Create design from template
  async createDesignFromTemplate(templateId: string, name: string): Promise<CanvaDesign> {
    try {
      const data = await this.makeRequest("/designs", {
        method: "POST",
        body: JSON.stringify({
          design_type: "presentation",
          name,
          template_id: templateId,
        }),
      })

      return data.design
    } catch (error) {
      console.error("Error creating design:", error)
      // Return mock design for demo
      return {
        id: `design_${Date.now()}`,
        name,
        thumbnail: "/placeholder.svg?height=300&width=300",
        urls: {
          edit_url: `https://canva.com/design/mock_${templateId}`,
          view_url: `https://canva.com/design/mock_${templateId}/view`,
        },
      }
    }
  }

  // Get premium assets
  async getPremiumAssets(type: "photos" | "elements" | "graphics" = "photos", query?: string): Promise<CanvaAsset[]> {
    try {
      const params = new URLSearchParams({
        type,
        limit: "20",
        ...(query && { query }),
      })

      const data = await this.makeRequest(`/assets?${params}`)
      return data.items || []
    } catch (error) {
      console.error("Error fetching assets:", error)
      return this.getMockAssets(type)
    }
  }

  // Export design
  async exportDesign(designId: string, format: "png" | "jpg" | "pdf" = "png"): Promise<string> {
    try {
      const data = await this.makeRequest(`/designs/${designId}/export`, {
        method: "POST",
        body: JSON.stringify({
          format,
          quality: "high",
        }),
      })

      return data.export_url
    } catch (error) {
      console.error("Error exporting design:", error)
      return "/placeholder.svg?height=400&width=400"
    }
  }

  // Get brand kit
  async getBrandKit(): Promise<any> {
    try {
      const data = await this.makeRequest("/brand-kits")
      return data.brand_kit
    } catch (error) {
      console.error("Error fetching brand kit:", error)
      return this.getMockBrandKit()
    }
  }

  // Mock data for demo purposes
  private getMockTemplates(category?: string): CanvaTemplate[] {
    const templates = [
      {
        id: "tpl_apparel_001",
        name: "Modern T-Shirt Design",
        thumbnail: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=300&h=300&fit=crop",
        category: "apparel",
        tags: ["modern", "minimalist", "typography"],
        isPremium: true,
      },
      {
        id: "tpl_apparel_002",
        name: "Vintage Hoodie Template",
        thumbnail: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=300&h=300&fit=crop",
        category: "apparel",
        tags: ["vintage", "retro", "graphic"],
        isPremium: true,
      },
      {
        id: "tpl_mug_001",
        name: "Coffee Quote Mug",
        thumbnail: "https://images.unsplash.com/photo-1514228742587-6b1558fcf93a?w=300&h=300&fit=crop",
        category: "home",
        tags: ["coffee", "quotes", "typography"],
        isPremium: false,
      },
      {
        id: "tpl_poster_001",
        name: "Abstract Art Poster",
        thumbnail: "https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=300&h=300&fit=crop",
        category: "home",
        tags: ["abstract", "art", "modern"],
        isPremium: true,
      },
      {
        id: "tpl_phone_001",
        name: "Geometric Phone Case",
        thumbnail: "https://images.unsplash.com/photo-1601593346740-925612772716?w=300&h=300&fit=crop",
        category: "accessories",
        tags: ["geometric", "pattern", "modern"],
        isPremium: true,
      },
    ]

    return category ? templates.filter((t) => t.category === category) : templates
  }

  private getMockAssets(type: string): CanvaAsset[] {
    const assets = [
      {
        id: "asset_001",
        name: "Abstract Background",
        thumbnail: "https://images.unsplash.com/photo-1557804506-669a67965ba0?w=200&h=200&fit=crop",
        type: "image" as const,
        isPremium: true,
        tags: ["abstract", "background", "colorful"],
      },
      {
        id: "asset_002",
        name: "Minimalist Icon Set",
        thumbnail: "https://images.unsplash.com/photo-1586953208448-b95a79798f07?w=200&h=200&fit=crop",
        type: "element" as const,
        isPremium: true,
        tags: ["icons", "minimalist", "ui"],
      },
      {
        id: "asset_003",
        name: "Nature Photography",
        thumbnail: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=200&h=200&fit=crop",
        type: "image" as const,
        isPremium: false,
        tags: ["nature", "landscape", "photography"],
      },
    ]

    return assets.filter((a) => (type === "photos" ? a.type === "image" : a.type === "element"))
  }

  private getMockBrandKit() {
    return {
      colors: ["#000000", "#FFFFFF", "#FF6B6B", "#4ECDC4", "#45B7D1"],
      fonts: ["Inter", "Roboto", "Playfair Display", "Montserrat"],
      logos: [
        {
          id: "logo_001",
          name: "Primary Logo",
          url: "/cc-wearables-logo.jpg",
        },
      ],
    }
  }
}

// Singleton instance
let canvaClient: CanvaAPIClient | null = null

export function initializeCanvaAPI(config: CanvaConfig) {
  canvaClient = new CanvaAPIClient(config)
  return canvaClient
}

export function getCanvaClient(): CanvaAPIClient {
  if (!canvaClient) {
    // Initialize with demo config if not set
    canvaClient = new CanvaAPIClient({
      apiKey: process.env.NEXT_PUBLIC_CANVA_API_KEY || "demo_key",
      teamId: process.env.NEXT_PUBLIC_CANVA_TEAM_ID,
    })
  }
  return canvaClient
}
