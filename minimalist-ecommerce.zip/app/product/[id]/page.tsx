"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Star, ShoppingCart, Heart, Share2, Truck, Shield, RotateCcw, Palette } from "lucide-react"
import { ProductImageGallery } from "@/components/product-image-gallery"
import { RelatedProducts } from "@/components/related-products"
import { CanvaDesignStudio } from "@/components/canva-design-studio"
import { useState } from "react"
import Link from "next/link"

// All products data combined from different categories
const allProducts = [
  // Electronics
  {
    id: "elec_001",
    name: "Apple AirPods Pro 2nd Gen",
    price: 3299,
    category: "electronics",
    image: "https://images.unsplash.com/photo-1606220945770-b5b6c2c55bf1?w=300&h=300&fit=crop",
    images: [
      "https://images.unsplash.com/photo-1606220945770-b5b6c2c55bf1?w=600&h=600&fit=crop",
      "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=600&h=600&fit=crop",
      "https://images.unsplash.com/photo-1583394838336-acd977736f90?w=600&h=600&fit=crop",
    ],
    description: "Advanced noise cancellation with spatial audio technology",
    detailedDescription:
      "The Apple AirPods Pro (2nd generation) deliver exceptional audio quality with advanced Active Noise Cancellation that's up to 2x more effective than the previous generation. Featuring the new H2 chip, these earbuds provide richer bass and clearer highs, while Adaptive Transparency lets you hear the world around you.",
    features: [
      "Up to 2x more Active Noise Cancellation",
      "Adaptive Transparency mode",
      "Personalized Spatial Audio with dynamic head tracking",
      "Up to 6 hours listening time with ANC on",
      "MagSafe Charging Case with up to 30 hours total listening time",
      "IPX4 sweat and water resistance",
      "Touch control for music, calls, and Siri",
    ],
    specifications: {
      "Battery Life": "Up to 6 hours (AirPods), Up to 30 hours (with case)",
      Connectivity: "Bluetooth 5.3",
      Chip: "Apple H2",
      "Water Resistance": "IPX4",
      Weight: "5.3g per AirPod",
      Charging: "Lightning, MagSafe, Qi wireless charging",
    },
    stock: 25,
    reviews: [
      { rating: 5, comment: "Amazing sound quality and noise cancellation!", author: "John D." },
      { rating: 5, comment: "Perfect for workouts and daily use.", author: "Sarah M." },
      { rating: 4, comment: "Great product, slightly expensive but worth it.", author: "Mike R." },
    ],
  },
  {
    id: "elec_002",
    name: "Samsung Galaxy Buds Pro",
    price: 1599,
    category: "electronics",
    image: "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=300&h=300&fit=crop",
    images: [
      "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=600&h=600&fit=crop",
      "https://images.unsplash.com/photo-1606220945770-b5b6c2c55bf1?w=600&h=600&fit=crop",
    ],
    description: "Premium sound quality with active noise cancellation",
    detailedDescription:
      "Samsung Galaxy Buds Pro deliver studio-quality sound with intelligent Active Noise Cancellation. The 11mm woofer and 6.5mm tweeter provide rich, balanced audio, while the 360 Audio feature creates an immersive listening experience.",
    features: [
      "Intelligent Active Noise Cancellation",
      "360 Audio with Dolby Head Tracking",
      "IPX7 water resistance",
      "Up to 8 hours battery life",
      "Wireless charging case",
      "Voice Detect technology",
      "Ambient Sound mode",
    ],
    specifications: {
      "Battery Life": "Up to 8 hours (earbuds), Up to 28 hours (with case)",
      Connectivity: "Bluetooth 5.0",
      "Water Resistance": "IPX7",
      Weight: "6.3g per earbud",
      Charging: "USB-C, Qi wireless charging",
    },
    stock: 50,
    reviews: [
      { rating: 4, comment: "Great value for money with excellent features.", author: "Lisa K." },
      { rating: 5, comment: "Love the 360 Audio feature!", author: "David P." },
    ],
  },
  // Clothing
  {
    id: "cloth_001",
    name: "Uniqlo Heattech Crew Neck T-Shirt",
    price: 399,
    category: "clothing",
    image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=300&h=300&fit=crop",
    images: [
      "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=600&h=600&fit=crop",
      "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=600&h=600&fit=crop",
    ],
    description: "Premium cotton with moisture-wicking technology",
    detailedDescription:
      "The Uniqlo Heattech Crew Neck T-Shirt combines comfort with innovative technology. Made with premium cotton blend and featuring moisture-wicking properties, this shirt keeps you comfortable throughout the day while maintaining a classic, minimalist design.",
    features: [
      "Heattech moisture-wicking technology",
      "Premium cotton blend fabric",
      "Crew neck design",
      "Machine washable",
      "Available in multiple colors",
      "Tagless for comfort",
      "Odor-resistant treatment",
    ],
    specifications: {
      Material: "Cotton blend with Heattech fibers",
      Fit: "Regular fit",
      Care: "Machine wash cold",
      Sizes: "XS, S, M, L, XL, XXL",
      Colors: "Black, White, Navy, Grey, Olive",
    },
    stock: 100,
    reviews: [
      { rating: 5, comment: "Super comfortable and great quality!", author: "Emma T." },
      { rating: 4, comment: "Perfect basic tee, fits well.", author: "Alex M." },
    ],
  },
  {
    id: "cloth_002",
    name: "Levi’s 501 Original Fit Jeans",
    price: 899,
    category: "clothing",
    image: "https://images.unsplash.com/photo-1514996937319-344454492b37?w=300&h=300&fit=crop",
    images: [
      "https://images.unsplash.com/photo-1514996937319-344454492b37?w=600&h=600&fit=crop",
      "https://images.unsplash.com/photo-1495121605193-b116b5b09f13?w=600&h=600&fit=crop",
    ],
    description: "Iconic straight-leg jeans made with durable denim.",
    detailedDescription:
      "Levi’s 501 Original Fit Jeans have defined style for decades. Cut from sturdy denim with a button-fly closure, these jeans provide timeless comfort and durability.",
    features: ["Straight leg", "Button fly", "Five-pocket styling", "100 % cotton denim", "Machine washable"],
    specifications: {
      Material: "100 % cotton denim",
      Fit: "Original straight",
      Rise: "Mid",
      Leg: "Straight",
      Sizes: "28-40 Waist, 30-34 Length",
      Colors: "Stonewash, Dark Indigo, Black",
    },
    stock: 40,
    reviews: [
      { rating: 5, comment: "Classic jeans that never go out of style.", author: "DenimFan" },
      { rating: 4, comment: "Great fit but runs a bit long.", author: "TallGuy" },
    ],
  },
  // Print on Demand
  {
    id: "pod_001",
    name: "Custom T-Shirt Design",
    price: 299,
    category: "print-on-demand",
    image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=300&h=300&fit=crop",
    images: [
      "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=600&h=600&fit=crop",
      "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=600&h=600&fit=crop",
    ],
    description: "Create your own design on premium cotton t-shirt",
    detailedDescription:
      "Design your perfect custom t-shirt with our premium 100% organic cotton base. Using state-of-the-art printing technology, your designs come to life with vibrant colors and lasting quality. Perfect for personal expression, gifts, or building your brand.",
    features: [
      "100% organic cotton fabric",
      "High-quality DTG printing",
      "Vibrant, long-lasting colors",
      "Soft, comfortable feel",
      "Machine washable",
      "Custom design placement",
      "Eco-friendly production",
    ],
    specifications: {
      Material: "100% organic cotton",
      "Print Method": "Direct-to-Garment (DTG)",
      "Print Areas": "Front, Back, Sleeves",
      Sizes: "XS, S, M, L, XL, XXL",
      Colors: "White, Black, Navy, Grey, Red",
      "Production Time": "3-5 business days",
    },
    stock: 0,
    isPrintOnDemand: true,
    printAreas: ["Front", "Back", "Left Sleeve", "Right Sleeve"],
    canvaTemplateId: "tshirt_basic",
    reviews: [
      { rating: 5, comment: "Amazing quality print and super soft fabric!", author: "Creative Co." },
      { rating: 5, comment: "Perfect for my business merchandise.", author: "StartupBrand" },
      { rating: 4, comment: "Great customization options.", author: "Designer123" },
    ],
  },
  {
    id: "pod_002",
    name: "Custom Hoodie Design",
    price: 699,
    category: "print-on-demand",
    image: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=300&h=300&fit=crop",
    images: [
      "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=600&h=600&fit=crop",
      "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=600&h=600&fit=crop",
    ],
    description: "Personalized hoodie with your custom artwork",
    detailedDescription:
      "Create the perfect custom hoodie with our premium fleece blend fabric. Featuring a comfortable fit, durable construction, and high-quality printing, these hoodies are perfect for showcasing your unique designs while staying warm and comfortable.",
    features: [
      "Premium fleece blend fabric",
      "Adjustable drawstring hood",
      "Kangaroo pocket",
      "Ribbed cuffs and hem",
      "High-quality screen printing",
      "Unisex sizing",
      "Pre-shrunk fabric",
    ],
    specifications: {
      Material: "80% cotton, 20% polyester fleece",
      "Print Method": "Screen printing / DTG",
      "Print Areas": "Front, Back, Sleeves, Hood",
      Sizes: "XS, S, M, L, XL, XXL",
      Colors: "Black, White, Navy, Grey, Maroon",
      "Production Time": "5-7 business days",
    },
    stock: 0,
    isPrintOnDemand: true,
    printAreas: ["Front", "Back", "Left Sleeve", "Right Sleeve", "Hood"],
    canvaTemplateId: "hoodie_basic",
    reviews: [
      { rating: 5, comment: "Excellent quality and perfect fit!", author: "Fashion Forward" },
      { rating: 5, comment: "Love the custom design options.", author: "Brand Builder" },
    ],
  },
]

interface ProductPageProps {
  params: {
    id: string
  }
}

export default function ProductPage({ params }: ProductPageProps) {
  const [selectedSize, setSelectedSize] = useState("M")
  const [selectedColor, setSelectedColor] = useState("Black")
  const [quantity, setQuantity] = useState(1)
  const [showDesignStudio, setShowDesignStudio] = useState(false)

  const product = allProducts.find((p) => p.id === params.id)

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <div className="text-center space-y-4">
          <h1 className="text-2xl font-bold">Product not found</h1>
          <Button asChild>
            <Link href="/">Back to home</Link>
          </Button>
        </div>
      </div>
    )
  }

  const averageRating = product.reviews?.length
    ? product.reviews.reduce((sum, review) => sum + review.rating, 0) / product.reviews.length
    : 0

  const relatedProducts = allProducts.filter((p) => p.category === product.category && p.id !== product.id).slice(0, 4)

  return (
    <div className="min-h-screen bg-white">
      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <nav className="mb-8 text-sm text-gray-600">
          <span>Home</span> / <span className="capitalize">{product.category}</span> /{" "}
          <span className="text-black">{product.name}</span>
        </nav>

        <div className="grid lg:grid-cols-2 gap-12 mb-16">
          {/* Product Images */}
          <div>
            <ProductImageGallery images={product.images || [product.image]} />
          </div>

          {/* Product Info */}
          <div>
            <div className="mb-4">
              {product.isPrintOnDemand && <Badge className="mb-2 bg-purple-100 text-purple-800">Customizable</Badge>}
              <h1 className="text-3xl font-bold text-black mb-2">{product.name}</h1>
              <div className="flex items-center gap-4 mb-4">
                <div className="flex items-center">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-5 h-5 ${
                        i < Math.floor(averageRating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                      }`}
                    />
                  ))}
                  <span className="ml-2 text-gray-600">({product.reviews?.length || 0} reviews)</span>
                </div>
              </div>
              <p className="text-3xl font-bold text-black mb-6">R{product.price}</p>
            </div>

            <p className="text-gray-600 mb-6">{product.description}</p>

            {/* Size Selection */}
            {(product.category === "clothing" || product.isPrintOnDemand) && (
              <div className="mb-6">
                <h3 className="font-semibold mb-3">Size</h3>
                <div className="flex gap-2">
                  {["XS", "S", "M", "L", "XL", "XXL"].map((size) => (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`px-4 py-2 border-2 ${
                        selectedSize === size
                          ? "border-black bg-black text-white"
                          : "border-gray-300 hover:border-gray-400"
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Color Selection */}
            {product.isPrintOnDemand && (
              <div className="mb-6">
                <h3 className="font-semibold mb-3">Color</h3>
                <div className="flex gap-2">
                  {["Black", "White", "Navy", "Grey", "Red"].map((color) => (
                    <button
                      key={color}
                      onClick={() => setSelectedColor(color)}
                      className={`px-4 py-2 border-2 ${
                        selectedColor === color
                          ? "border-black bg-black text-white"
                          : "border-gray-300 hover:border-gray-400"
                      }`}
                    >
                      {color}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Quantity */}
            <div className="mb-6">
              <h3 className="font-semibold mb-3">Quantity</h3>
              <div className="flex items-center gap-4">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-3 py-1 border border-gray-300 hover:bg-gray-100"
                >
                  -
                </button>
                <span className="px-4 py-1 border border-gray-300">{quantity}</span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="px-3 py-1 border border-gray-300 hover:bg-gray-100"
                >
                  +
                </button>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-4 mb-8">
              {product.isPrintOnDemand && (
                <Button
                  onClick={() => setShowDesignStudio(true)}
                  className="w-full bg-purple-600 hover:bg-purple-700 text-white py-3"
                  size="lg"
                >
                  <Palette className="mr-2 h-5 w-5" />
                  Customize Design
                </Button>
              )}

              <Button className="w-full bg-black hover:bg-gray-800 text-white py-3" size="lg">
                <ShoppingCart className="mr-2 h-5 w-5" />
                Add to Cart
              </Button>

              <div className="flex gap-4">
                <Button variant="outline" className="flex-1 bg-transparent">
                  <Heart className="mr-2 h-4 w-4" />
                  Save
                </Button>
                <Button variant="outline" className="flex-1 bg-transparent">
                  <Share2 className="mr-2 h-4 w-4" />
                  Share
                </Button>
              </div>
            </div>

            {/* Features */}
            <div className="border-t pt-6">
              <div className="grid grid-cols-3 gap-4 text-center">
                <div className="flex flex-col items-center">
                  <Truck className="h-6 w-6 mb-2" />
                  <span className="text-sm">Free Shipping</span>
                </div>
                <div className="flex flex-col items-center">
                  <RotateCcw className="h-6 w-6 mb-2" />
                  <span className="text-sm">Easy Returns</span>
                </div>
                <div className="flex flex-col items-center">
                  <Shield className="h-6 w-6 mb-2" />
                  <span className="text-sm">Secure Payment</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Product Details Tabs */}
        <Tabs defaultValue="description" className="mb-16">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="description">Description</TabsTrigger>
            <TabsTrigger value="specifications">Specifications</TabsTrigger>
            <TabsTrigger value="reviews">Reviews</TabsTrigger>
            <TabsTrigger value="shipping">Shipping</TabsTrigger>
          </TabsList>

          <TabsContent value="description" className="mt-6">
            <Card>
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold mb-4">Product Description</h3>
                <p className="text-gray-600 mb-6">{product.detailedDescription}</p>

                {product.features && (
                  <div>
                    <h4 className="font-semibold mb-3">Key Features:</h4>
                    <ul className="list-disc list-inside space-y-2 text-gray-600">
                      {product.features.map((feature, index) => (
                        <li key={index}>{feature}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="specifications" className="mt-6">
            <Card>
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold mb-4">Specifications</h3>
                {product.specifications && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {Object.entries(product.specifications).map(([key, value]) => (
                      <div key={key} className="flex justify-between border-b pb-2">
                        <span className="font-medium">{key}:</span>
                        <span className="text-gray-600">{value}</span>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reviews" className="mt-6">
            <Card>
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold mb-4">Customer Reviews</h3>
                <div className="space-y-6">
                  {product.reviews?.map((review, index) => (
                    <div key={index} className="border-b pb-4">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="flex">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-4 h-4 ${
                                i < review.rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                              }`}
                            />
                          ))}
                        </div>
                        <span className="font-medium">{review.author}</span>
                      </div>
                      <p className="text-gray-600">{review.comment}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="shipping" className="mt-6">
            <Card>
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold mb-4">Shipping Information</h3>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium mb-2">Standard Shipping</h4>
                    <p className="text-gray-600">Free shipping on orders over R500. Delivery in 3-5 business days.</p>
                  </div>
                  <div>
                    <h4 className="font-medium mb-2">Express Shipping</h4>
                    <p className="text-gray-600">R99 for next-day delivery. Order before 2 PM for same-day dispatch.</p>
                  </div>
                  {product.isPrintOnDemand && (
                    <div>
                      <h4 className="font-medium mb-2">Custom Products</h4>
                      <p className="text-gray-600">
                        Production time: {product.specifications?.["Production Time"] || "3-5 business days"}. Shipping
                        time is additional to production time.
                      </p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Related Products */}
        {relatedProducts.length > 0 && <RelatedProducts products={relatedProducts} />}
      </div>

      {/* Canva Design Studio Modal */}
      {showDesignStudio && product.isPrintOnDemand && (
        <CanvaDesignStudio
          isOpen={showDesignStudio}
          onClose={() => setShowDesignStudio(false)}
          product={product}
          selectedSize={selectedSize}
          selectedColor={selectedColor}
        />
      )}
    </div>
  )
}
