import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { supplierApi, apiKey, profitMargin = 16.67 } = await request.json()

    // Simulate product import from supplier API
    const mockProducts = [
      {
        id: "sup_001",
        name: "Smart Fitness Band Pro",
        cost: 1200,
        description: "Advanced fitness tracking with heart rate monitor",
        image: "/placeholder.svg?height=300&width=300",
        category: "wearables",
        stock: 50,
      },
      {
        id: "sup_002",
        name: "Wireless Charging Pad",
        cost: 300,
        description: "Fast wireless charging for all devices",
        image: "/placeholder.svg?height=300&width=300",
        category: "electronics",
        stock: 100,
      },
      {
        id: "sup_003",
        name: "Bluetooth Sport Earbuds",
        cost: 800,
        description: "Waterproof earbuds for active lifestyle",
        image: "/placeholder.svg?height=300&width=300",
        category: "electronics",
        stock: 75,
      },
    ]

    // Calculate selling prices with profit margin
    const importedProducts = mockProducts.map((product) => ({
      ...product,
      sellingPrice: Math.round(product.cost * (1 + profitMargin / 100)),
      profit: Math.round(product.cost * (profitMargin / 100)),
      supplierUrl: `${supplierApi}/products/${product.id}`,
      autoFulfill: true,
    }))

    return NextResponse.json({
      success: true,
      imported: importedProducts.length,
      products: importedProducts,
      message: `Successfully imported ${importedProducts.length} products with ${profitMargin}% profit margin`,
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: "Import failed" }, { status: 500 })
  }
}
