import { type NextRequest, NextResponse } from "next/server"

// Mock product data - in a real app, this would come from a database
const products = [
  {
    id: "elec_001",
    name: "Apple AirPods Pro 2nd Gen",
    price: 3299,
    category: "electronics",
    image: "https://images.unsplash.com/photo-1606220945770-b5b6c2c55bf1?w=300&h=300&fit=crop",
    description: "Advanced noise cancellation with spatial audio technology",
    stock: 25,
  },
  {
    id: "pod_001",
    name: "Custom T-Shirt Design",
    price: 299,
    category: "print-on-demand",
    image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=300&h=300&fit=crop",
    description: "Create your own design on premium cotton t-shirt",
    isPrintOnDemand: true,
    stock: 0,
  },
  // Add more products as needed
]

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const product = products.find((p) => p.id === params.id)

    if (!product) {
      return NextResponse.json({ error: "Product not found" }, { status: 404 })
    }

    return NextResponse.json(product)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch product" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const body = await request.json()
    const productIndex = products.findIndex((p) => p.id === params.id)

    if (productIndex === -1) {
      return NextResponse.json({ error: "Product not found" }, { status: 404 })
    }

    // Update product
    products[productIndex] = { ...products[productIndex], ...body }

    return NextResponse.json(products[productIndex])
  } catch (error) {
    return NextResponse.json({ error: "Failed to update product" }, { status: 500 })
  }
}
