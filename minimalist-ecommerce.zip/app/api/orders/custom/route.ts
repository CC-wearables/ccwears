import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { orderId, customerDetails, customDesign, baseProduct } = await request.json()

    // Select appropriate production partner based on product type
    const productionPartners = {
      apparel: {
        name: "PrintHub SA",
        apiEndpoint: "https://api.printhub.co.za/orders",
        productionTime: "2-3 days",
        shippingTime: "3-5 days",
      },
      accessories: {
        name: "Custom Creations",
        apiEndpoint: "https://api.customcreations.co.za/orders",
        productionTime: "1-2 days",
        shippingTime: "2-4 days",
      },
      home: {
        name: "Print & Ship Co",
        apiEndpoint: "https://api.printship.co.za/orders",
        productionTime: "2-4 days",
        shippingTime: "3-6 days",
      },
    }

    // Determine product category
    const productCategory =
      baseProduct.includes("shirt") || baseProduct.includes("hoodie")
        ? "apparel"
        : baseProduct.includes("mug") || baseProduct.includes("poster")
          ? "home"
          : "accessories"

    const selectedPartner = productionPartners[productCategory]

    // Create production order
    const productionOrder = {
      orderId: `PROD-${Date.now()}`,
      customerOrder: orderId,
      partner: selectedPartner.name,
      product: {
        type: baseProduct,
        design: customDesign,
      },
      shipping: {
        name: `${customerDetails.firstName} ${customerDetails.lastName}`,
        address: customerDetails.address,
        city: customerDetails.city,
        postalCode: customerDetails.postalCode,
        phone: customerDetails.phone,
        email: customerDetails.email,
      },
      timeline: {
        production: selectedPartner.productionTime,
        shipping: selectedPartner.shippingTime,
        estimated: calculateDeliveryDate(selectedPartner.productionTime, selectedPartner.shippingTime),
      },
    }

    // Simulate sending order to production partner
    console.log(`📦 Sending custom order to ${selectedPartner.name}:`, productionOrder)

    // Generate tracking number
    const trackingNumber = `CC${Date.now()}${Math.floor(Math.random() * 1000)}`

    return NextResponse.json({
      success: true,
      productionOrder: productionOrder.orderId,
      partner: selectedPartner.name,
      trackingNumber,
      estimatedDelivery: productionOrder.timeline.estimated,
      message: `Custom order sent to ${selectedPartner.name} for production. Customer will receive tracking info.`,
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: "Custom order processing failed" }, { status: 500 })
  }
}

function calculateDeliveryDate(productionTime: string, shippingTime: string): string {
  // Extract max days from ranges like "2-3 days"
  const prodDays = Number.parseInt(productionTime.split("-")[1] || productionTime.split(" ")[0])
  const shipDays = Number.parseInt(shippingTime.split("-")[1] || shippingTime.split(" ")[0])

  const totalDays = prodDays + shipDays
  const deliveryDate = new Date()
  deliveryDate.setDate(deliveryDate.getDate() + totalDays)

  return deliveryDate.toLocaleDateString()
}
