"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Mail, Calendar, Users, TrendingUp, Search, Filter, Eye } from "lucide-react"

interface EmailCampaign {
  id: string
  subject: string
  type: "admin" | "products" | "support" | "marketing" | "newsletter"
  fromEmail: string
  sentDate: string
  recipients: number
  openRate: number
  clickRate: number
  status: "sent" | "draft" | "scheduled"
  preview: string
  content: string
}

export default function EmailsPage() {
  const [emailCampaigns, setEmailCampaigns] = useState<EmailCampaign[]>([])
  const [filteredEmails, setFilteredEmails] = useState<EmailCampaign[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [filterType, setFilterType] = useState("all")
  const [selectedEmail, setSelectedEmail] = useState<EmailCampaign | null>(null)

  useEffect(() => {
    // Load email campaigns from localStorage or API
    const savedEmails = localStorage.getItem("email_campaigns")
    if (savedEmails) {
      const emails = JSON.parse(savedEmails)
      setEmailCampaigns(emails)
      setFilteredEmails(emails)
    } else {
      // Mock data for demonstration
      const mockEmails: EmailCampaign[] = [
        {
          id: "email_1",
          subject: "🔥 New Trending Products Alert - Viral LED Strips & More!",
          type: "products",
          fromEmail: "products@ccwearables.com",
          sentDate: "2024-01-15T10:30:00Z",
          recipients: 2847,
          openRate: 34.2,
          clickRate: 8.7,
          status: "sent",
          preview: "Discover the latest trending products taking South Africa by storm...",
          content: "Full email content here...",
        },
        {
          id: "email_2",
          subject: "Welcome to CC Wearables - Your Premium Tech & Fashion Destination",
          type: "newsletter",
          fromEmail: "hello@ccwearables.com",
          sentDate: "2024-01-14T09:00:00Z",
          recipients: 156,
          openRate: 45.8,
          clickRate: 12.3,
          status: "sent",
          preview: "Thank you for joining the CC Wearables family...",
          content: "Full welcome email content...",
        },
        {
          id: "email_3",
          subject: "System Maintenance Scheduled - Admin Notification",
          type: "admin",
          fromEmail: "admin@ccwearables.com",
          sentDate: "2024-01-13T16:45:00Z",
          recipients: 5,
          openRate: 100,
          clickRate: 60,
          status: "sent",
          preview: "Scheduled maintenance window for system updates...",
          content: "Admin notification content...",
        },
        {
          id: "email_4",
          subject: "Customer Support Update - New Consultant Team",
          type: "support",
          fromEmail: "support@ccwearables.com",
          sentDate: "2024-01-12T14:20:00Z",
          recipients: 1203,
          openRate: 28.9,
          clickRate: 5.4,
          status: "sent",
          preview: "We're excited to announce our expanded support team...",
          content: "Support update content...",
        },
        {
          id: "email_5",
          subject: "Flash Sale - 30% Off Electronics This Weekend Only!",
          type: "marketing",
          fromEmail: "deals@ccwearables.com",
          sentDate: "2024-01-11T08:00:00Z",
          recipients: 4521,
          openRate: 41.7,
          clickRate: 15.2,
          status: "sent",
          preview: "Don't miss out on our biggest electronics sale of the year...",
          content: "Marketing email content...",
        },
      ]
      setEmailCampaigns(mockEmails)
      setFilteredEmails(mockEmails)
      localStorage.setItem("email_campaigns", JSON.stringify(mockEmails))
    }
  }, [])

  useEffect(() => {
    let filtered = emailCampaigns

    if (searchTerm) {
      filtered = filtered.filter(
        (email) =>
          email.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
          email.preview.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    }

    if (filterType !== "all") {
      filtered = filtered.filter((email) => email.type === filterType)
    }

    setFilteredEmails(filtered)
  }, [searchTerm, filterType, emailCampaigns])

  const getTypeColor = (type: string) => {
    switch (type) {
      case "admin":
        return "bg-red-100 text-red-800"
      case "products":
        return "bg-blue-100 text-blue-800"
      case "support":
        return "bg-green-100 text-green-800"
      case "marketing":
        return "bg-purple-100 text-purple-800"
      case "newsletter":
        return "bg-orange-100 text-orange-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "sent":
        return "bg-green-100 text-green-800"
      case "draft":
        return "bg-yellow-100 text-yellow-800"
      case "scheduled":
        return "bg-blue-100 text-blue-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const totalStats = {
    totalEmails: emailCampaigns.length,
    totalRecipients: emailCampaigns.reduce((sum, email) => sum + email.recipients, 0),
    avgOpenRate: emailCampaigns.reduce((sum, email) => sum + email.openRate, 0) / emailCampaigns.length,
    avgClickRate: emailCampaigns.reduce((sum, email) => sum + email.clickRate, 0) / emailCampaigns.length,
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold text-black">Email Campaigns</h1>
            <p className="text-gray-600">Recent email pushes and campaign performance</p>
          </div>
          <Button className="bg-black text-white hover:bg-gray-800">
            <Mail className="mr-2 h-4 w-4" />
            Create Campaign
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Campaigns</p>
                  <p className="text-2xl font-bold">{totalStats.totalEmails}</p>
                </div>
                <Mail className="h-8 w-8 text-gray-400" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Recipients</p>
                  <p className="text-2xl font-bold">{totalStats.totalRecipients.toLocaleString()}</p>
                </div>
                <Users className="h-8 w-8 text-gray-400" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Avg Open Rate</p>
                  <p className="text-2xl font-bold">{totalStats.avgOpenRate.toFixed(1)}%</p>
                </div>
                <Eye className="h-8 w-8 text-gray-400" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Avg Click Rate</p>
                  <p className="text-2xl font-bold">{totalStats.avgClickRate.toFixed(1)}%</p>
                </div>
                <TrendingUp className="h-8 w-8 text-gray-400" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input
                    placeholder="Search campaigns..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div className="flex gap-2">
                <Select value={filterType} onValueChange={setFilterType}>
                  <SelectTrigger className="w-48">
                    <Filter className="mr-2 h-4 w-4" />
                    <SelectValue placeholder="Filter by type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="admin">Admin</SelectItem>
                    <SelectItem value="products">Products</SelectItem>
                    <SelectItem value="support">Support</SelectItem>
                    <SelectItem value="marketing">Marketing</SelectItem>
                    <SelectItem value="newsletter">Newsletter</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Email Campaigns List */}
        <div className="grid gap-6">
          {filteredEmails.map((email) => (
            <Card key={email.id} className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-semibold">{email.subject}</h3>
                      <Badge className={getTypeColor(email.type)}>{email.type}</Badge>
                      <Badge className={getStatusColor(email.status)}>{email.status}</Badge>
                    </div>
                    <p className="text-gray-600 mb-2">{email.preview}</p>
                    <div className="flex items-center gap-4 text-sm text-gray-500">
                      <span className="flex items-center gap-1">
                        <Mail className="h-4 w-4" />
                        {email.fromEmail}
                      </span>
                      <span className="flex items-center gap-1">
                        <Calendar className="h-4 w-4" />
                        {new Date(email.sentDate).toLocaleDateString()}
                      </span>
                      <span className="flex items-center gap-1">
                        <Users className="h-4 w-4" />
                        {email.recipients.toLocaleString()} recipients
                      </span>
                    </div>
                  </div>
                  <Button variant="outline" size="sm" onClick={() => setSelectedEmail(email)}>
                    <Eye className="h-4 w-4 mr-2" />
                    View
                  </Button>
                </div>

                {/* Performance Metrics */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t">
                  <div className="text-center">
                    <p className="text-sm text-gray-600">Open Rate</p>
                    <p className="text-lg font-semibold text-green-600">{email.openRate}%</p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm text-gray-600">Click Rate</p>
                    <p className="text-lg font-semibold text-blue-600">{email.clickRate}%</p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm text-gray-600">Recipients</p>
                    <p className="text-lg font-semibold">{email.recipients.toLocaleString()}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm text-gray-600">Sent Date</p>
                    <p className="text-lg font-semibold">{new Date(email.sentDate).toLocaleDateString()}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredEmails.length === 0 && (
          <Card>
            <CardContent className="p-12 text-center">
              <Mail className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No campaigns found</h3>
              <p className="text-gray-600">Try adjusting your search or filter criteria</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
