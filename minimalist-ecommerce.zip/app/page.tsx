"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import {
  ShoppingBag,
  Truck,
  Shield,
  Star,
  ArrowRight,
  Zap,
  Smartphone,
  Shirt,
  Palette,
  CheckCircle,
  Mail,
} from "lucide-react"
import { useState } from "react"

export default function HomePage() {
  const [email, setEmail] = useState("")

  const handleNewsletterSignup = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle newsletter signup
    console.log("Newsletter signup:", email)
    setEmail("")
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative py-20 px-4 text-center bg-gradient-to-b from-gray-50 to-white">
        <div className="container mx-auto max-w-6xl">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-7xl font-bold text-black mb-6 leading-tight">
              Discover Premium Wearable Technology & Fashion
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 mb-8 leading-relaxed">
              Where cutting-edge technology meets contemporary style. We curate the finest selection of smart
              electronics, premium clothing, and custom print-on-demand products for the modern South African consumer.
              Experience innovation that enhances your lifestyle while expressing your unique personality.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="bg-black text-white hover:bg-gray-800 px-8 py-4 text-lg">
                <Link href="/catalog/electronics">
                  <Smartphone className="mr-2 h-5 w-5" />
                  Explore Electronics
                </Link>
              </Button>
              <Button
                asChild
                variant="outline"
                size="lg"
                className="border-black text-black hover:bg-gray-50 px-8 py-4 text-lg bg-transparent"
              >
                <Link href="/trending">
                  <Zap className="mr-2 h-5 w-5" />
                  View Trending
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Category Showcase */}
      <section className="py-20 px-4 bg-white">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-black mb-6">Explore Our Premium Collections</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              From cutting-edge smart devices to fashion-forward apparel and personalized custom designs, discover
              products that define the future of style and functionality.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Electronics */}
            <Card className="group hover:shadow-2xl transition-all duration-300 border-2 border-gray-100 hover:border-black">
              <div className="relative overflow-hidden">
                <img
                  src="https://images.unsplash.com/photo-1498049794561-7780e7231661?w=600&h=400&fit=crop"
                  alt="Smart Electronics Workspace"
                  className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-4 left-4">
                  <Badge className="bg-blue-600 text-white">Smart Tech</Badge>
                </div>
              </div>
              <CardHeader>
                <CardTitle className="text-2xl font-bold flex items-center">
                  <Smartphone className="mr-3 h-6 w-6" />
                  Smart Electronics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  Discover the latest in wearable technology, smart devices, and innovative electronics. From fitness
                  trackers to wireless earbuds, we bring you premium tech that seamlessly integrates into your daily
                  routine.
                </p>
                <div className="space-y-2 mb-6">
                  <div className="flex items-center text-sm text-gray-600">
                    <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                    Latest smartwatches and fitness trackers
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                    Premium wireless audio devices
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                    Smart home and IoT accessories
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                    Mobile accessories and power solutions
                  </div>
                </div>
                <Button asChild className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                  <Link href="/catalog/electronics">
                    Shop Electronics
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </CardContent>
            </Card>

            {/* Clothing */}
            <Card className="group hover:shadow-2xl transition-all duration-300 border-2 border-gray-100 hover:border-black">
              <div className="relative overflow-hidden">
                <img
                  src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=600&h=400&fit=crop"
                  alt="Premium Fashion Retail"
                  className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-4 left-4">
                  <Badge className="bg-purple-600 text-white">Premium Fashion</Badge>
                </div>
              </div>
              <CardHeader>
                <CardTitle className="text-2xl font-bold flex items-center">
                  <Shirt className="mr-3 h-6 w-6" />
                  Premium Clothing
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  Elevate your wardrobe with our carefully curated collection of premium apparel. From contemporary
                  streetwear to sophisticated business attire, find pieces that reflect your personal style and quality
                  standards.
                </p>
                <div className="space-y-2 mb-6">
                  <div className="flex items-center text-sm text-gray-600">
                    <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                    Contemporary streetwear and casual wear
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                    Professional business attire
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                    Athletic and activewear collections
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                    Seasonal and limited edition pieces
                  </div>
                </div>
                <Button asChild className="w-full bg-purple-600 hover:bg-purple-700 text-white">
                  <Link href="/catalog/clothing">
                    Shop Clothing
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </CardContent>
            </Card>

            {/* Print-on-Demand */}
            <Card className="group hover:shadow-2xl transition-all duration-300 border-2 border-gray-100 hover:border-black">
              <div className="relative overflow-hidden">
                <img
                  src="https://images.unsplash.com/photo-1572044162444-ad60f128bdea?w=600&h=400&fit=crop"
                  alt="Custom Design Studio"
                  className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-4 left-4">
                  <Badge className="bg-orange-600 text-white">Custom Design</Badge>
                </div>
              </div>
              <CardHeader>
                <CardTitle className="text-2xl font-bold flex items-center">
                  <Palette className="mr-3 h-6 w-6" />
                  Custom Print-on-Demand
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  Bring your creative vision to life with our advanced print-on-demand services. Design custom apparel,
                  accessories, and home décor items that are uniquely yours. Perfect for personal expression or business
                  branding.
                </p>
                <div className="space-y-2 mb-6">
                  <div className="flex items-center text-sm text-gray-600">
                    <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                    Custom t-shirts, hoodies, and apparel
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                    Personalized accessories and bags
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                    Home décor and wall art
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                    Business branding and promotional items
                  </div>
                </div>
                <Button asChild className="w-full bg-orange-600 hover:bg-orange-700 text-white">
                  <Link href="/catalog/print-on-demand">
                    Start Designing
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 bg-gray-50">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-black mb-6">Why Choose CC Wearables?</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We're committed to delivering exceptional value through premium products, outstanding service, and
              innovative technology solutions.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="bg-white p-6 rounded-full w-20 h-20 mx-auto mb-6 flex items-center justify-center shadow-lg">
                <Truck className="h-10 w-10 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold mb-4">Fast & Reliable Shipping</h3>
              <p className="text-gray-600 leading-relaxed">
                Experience lightning-fast delivery across South Africa with our premium shipping partners. Track your
                order in real-time and enjoy free shipping on orders over R500. Most orders arrive within 1-3 business
                days.
              </p>
            </div>

            <div className="text-center">
              <div className="bg-white p-6 rounded-full w-20 h-20 mx-auto mb-6 flex items-center justify-center shadow-lg">
                <Shield className="h-10 w-10 text-green-600" />
              </div>
              <h3 className="text-xl font-bold mb-4">Secure & Trusted</h3>
              <p className="text-gray-600 leading-relaxed">
                Shop with confidence using our bank-grade security and encrypted payment processing. Your personal
                information is protected with industry-leading security measures. We're committed to maintaining your
                privacy and trust.
              </p>
            </div>

            <div className="text-center">
              <div className="bg-white p-6 rounded-full w-20 h-20 mx-auto mb-6 flex items-center justify-center shadow-lg">
                <Star className="h-10 w-10 text-yellow-600" />
              </div>
              <h3 className="text-xl font-bold mb-4">Premium Quality</h3>
              <p className="text-gray-600 leading-relaxed">
                Every product in our collection is carefully vetted for quality, durability, and style. We partner with
                trusted brands and manufacturers to ensure you receive only the finest items. Quality is our promise to
                you.
              </p>
            </div>

            <div className="text-center">
              <div className="bg-white p-6 rounded-full w-20 h-20 mx-auto mb-6 flex items-center justify-center shadow-lg">
                <ShoppingBag className="h-10 w-10 text-purple-600" />
              </div>
              <h3 className="text-xl font-bold mb-4">Easy Returns</h3>
              <p className="text-gray-600 leading-relaxed">
                Not completely satisfied? No problem. Our hassle-free 30-day return policy ensures your complete
                satisfaction. Simply contact our support team, and we'll make it right. Your happiness is our priority.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Brand Story Section */}
      <section className="py-20 px-4 bg-white">
        <div className="container mx-auto max-w-4xl text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-black mb-8">Our Story</h2>
          <div className="space-y-6 text-lg text-gray-600 leading-relaxed">
            <p>
              Founded with a vision to bridge the gap between cutting-edge technology and contemporary fashion, CC
              Wearables emerged from a passion for innovation and style. We recognized that modern consumers demand
              products that not only perform exceptionally but also reflect their personal aesthetic and values.
            </p>
            <p>
              Our journey began with a simple belief: that technology should enhance life, not complicate it. We curate
              each product with meticulous attention to detail, ensuring that every item in our collection meets our
              rigorous standards for quality, functionality, and design. From the latest smartwatches to premium apparel
              and custom print solutions, we're committed to offering products that inspire and empower.
            </p>
            <p>
              Today, CC Wearables serves customers across South Africa, delivering premium products that define the
              intersection of technology and fashion. We're not just a retailer; we're your partners in discovering
              products that elevate your lifestyle and express your unique identity.
            </p>
          </div>
        </div>
      </section>

      {/* Customer Testimonials */}
      <section className="py-20 px-4 bg-gray-50">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-black mb-6">What Our Customers Say</h2>
            <p className="text-xl text-gray-600">
              Join thousands of satisfied customers who trust CC Wearables for their tech and fashion needs.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-2 border-gray-100">
              <CardContent className="p-8">
                <div className="flex mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  "Absolutely love my new smartwatch from CC Wearables! The quality is outstanding, and the customer
                  service was exceptional. Fast delivery to Cape Town too!"
                </p>
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mr-4">
                    <span className="text-blue-600 font-bold">SM</span>
                  </div>
                  <div>
                    <p className="font-semibold">Sarah M.</p>
                    <p className="text-sm text-gray-500">Cape Town</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-2 border-gray-100">
              <CardContent className="p-8">
                <div className="flex mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  "The custom print service is amazing! Created branded t-shirts for my business, and the quality
                  exceeded my expectations. Will definitely order again."
                </p>
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mr-4">
                    <span className="text-green-600 font-bold">MK</span>
                  </div>
                  <div>
                    <p className="font-semibold">Mike K.</p>
                    <p className="text-sm text-gray-500">Johannesburg</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-2 border-gray-100">
              <CardContent className="p-8">
                <div className="flex mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  "Found the perfect outfit for my new job! The clothing quality is premium, and the fit is perfect. CC
                  Wearables has become my go-to fashion destination."
                </p>
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mr-4">
                    <span className="text-purple-600 font-bold">LN</span>
                  </div>
                  <div>
                    <p className="font-semibold">Lisa N.</p>
                    <p className="text-sm text-gray-500">Durban</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 px-4 bg-black text-white">
        <div className="container mx-auto max-w-4xl text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">Ready to Discover Your Next Favorite Product?</h2>
          <p className="text-xl text-gray-300 mb-8 leading-relaxed">
            Explore our curated collections and find products that perfectly match your lifestyle and aspirations. From
            cutting-edge electronics to premium fashion and custom designs, your perfect product awaits.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-white text-black hover:bg-gray-100 px-8 py-4 text-lg">
              <Link href="/catalog/electronics">
                <Smartphone className="mr-2 h-5 w-5" />
                Shop Electronics
              </Link>
            </Button>
            <Button
              asChild
              variant="outline"
              size="lg"
              className="border-white text-white hover:bg-white hover:text-black px-8 py-4 text-lg bg-transparent"
            >
              <Link href="/catalog/clothing">
                <Shirt className="mr-2 h-5 w-5" />
                Browse Fashion
              </Link>
            </Button>
            <Button
              asChild
              variant="outline"
              size="lg"
              className="border-white text-white hover:bg-white hover:text-black px-8 py-4 text-lg bg-transparent"
            >
              <Link href="/catalog/print-on-demand">
                <Palette className="mr-2 h-5 w-5" />
                Create Custom
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Newsletter Signup */}
      <section className="py-16 px-4 bg-gray-50">
        <div className="container mx-auto max-w-2xl text-center">
          <div className="bg-white p-8 rounded-2xl shadow-lg">
            <Mail className="h-12 w-12 text-blue-600 mx-auto mb-6" />
            <h3 className="text-3xl font-bold text-black mb-4">Stay in the Loop</h3>
            <p className="text-gray-600 mb-6 leading-relaxed">
              Be the first to know about new arrivals, exclusive deals, and trending products. Join our newsletter for
              insider access to the latest in tech and fashion.
            </p>
            <form onSubmit={handleNewsletterSignup} className="flex flex-col sm:flex-row gap-4">
              <Input
                type="email"
                placeholder="Enter your email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="flex-1 px-4 py-3 text-lg"
              />
              <Button type="submit" size="lg" className="bg-black text-white hover:bg-gray-800 px-8 py-3 text-lg">
                Subscribe
              </Button>
            </form>
            <p className="text-sm text-gray-500 mt-4">No spam, unsubscribe at any time. We respect your privacy.</p>
          </div>
        </div>
      </section>
    </div>
  )
}
