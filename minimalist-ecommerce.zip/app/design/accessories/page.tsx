"use client"

import { CanvaDesignStudio } from "@/components/canva-design-studio"
import { CategoryHero } from "@/components/category-hero"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Zap } from "lucide-react"

const accessoryProducts = [
  {
    id: "acc_phone",
    name: "Phone Case",
    price: 199,
    image: "https://images.unsplash.com/photo-1601593346740-925612772716?w=300&h=300&fit=crop",
    canvaTemplateId: "phone-case-basic",
    printAreas: ["back"],
  },
  {
    id: "acc_tote",
    name: "Tote Bag",
    price: 299,
    image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=300&h=300&fit=crop",
    canvaTemplateId: "tote-bag-basic",
    printAreas: ["front", "back"],
  },
  {
    id: "acc_cap",
    name: "Baseball Cap",
    price: 249,
    image: "https://images.unsplash.com/photo-1588850561407-ed78c282e89b?w=300&h=300&fit=crop",
    canvaTemplateId: "cap-basic",
    printAreas: ["front", "back", "side"],
  },
  {
    id: "acc_backpack",
    name: "Backpack",
    price: 599,
    image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=300&h=300&fit=crop",
    canvaTemplateId: "backpack-basic",
    printAreas: ["front", "back"],
  },
]

const designEssentials = [
  {
    title: "Brand Elements",
    description: "Logos, icons, and brand-focused design elements",
    icon: "🏷️",
    features: ["Logo templates", "Brand colors", "Icon libraries"],
  },
  {
    title: "Patterns",
    description: "Seamless patterns and textures for accessories",
    icon: "🔄",
    features: ["Geometric patterns", "Textures", "Backgrounds"],
  },
  {
    title: "Mockups",
    description: "Realistic product mockups for visualization",
    icon: "📱",
    features: ["3D mockups", "Lifestyle shots", "Product angles"],
  },
  {
    title: "Effects",
    description: "Special effects and finishing touches",
    icon: "✨",
    features: ["Gradients", "Shadows", "Metallic effects"],
  },
]

export default function AccessoriesDesignPage() {
  return (
    <div className="min-h-screen bg-white">
      <CategoryHero
        title="Accessories Design Studio"
        description="Design custom accessories that make a statement"
        image="https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800&h=400&fit=crop"
      />

      {/* Design Essentials */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-black mb-4">Design Essentials</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Professional tools and elements specifically curated for accessory design
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {designEssentials.map((essential, index) => (
              <Card key={index} className="border-2 border-gray-200 hover:border-black transition-colors">
                <CardHeader className="text-center">
                  <div className="text-4xl mb-4">{essential.icon}</div>
                  <CardTitle className="text-xl">{essential.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">{essential.description}</p>
                  <ul className="space-y-2">
                    {essential.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center text-sm">
                        <Zap className="h-4 w-4 text-green-500 mr-2" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Product Selection */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-black mb-8 text-center">Choose Your Accessory</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {accessoryProducts.map((product) => (
              <Card
                key={product.id}
                className="border-2 border-gray-200 hover:border-black transition-colors cursor-pointer"
              >
                <CardContent className="p-4">
                  <img
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    className="w-full h-48 object-cover rounded mb-4"
                  />
                  <h3 className="font-bold text-lg mb-2">{product.name}</h3>
                  <p className="text-2xl font-bold text-black mb-2">R{product.price}</p>
                  <div className="flex flex-wrap gap-1">
                    {product.printAreas.map((area) => (
                      <span key={area} className="px-2 py-1 bg-gray-100 text-xs rounded">
                        {area}
                      </span>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Canva Design Studio */}
      <CanvaDesignStudio category="accessories" products={accessoryProducts} designType="accessories" />
    </div>
  )
}
