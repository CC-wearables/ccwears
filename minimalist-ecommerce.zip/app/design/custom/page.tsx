"use client"

import { CanvaDesignStudio } from "@/components/canva-design-studio"
import { CategoryHero } from "@/components/category-hero"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Palette, Upload, Sparkles } from "lucide-react"

const customDesignFeatures = [
  {
    title: "Upload Your Art",
    description: "Bring your own designs and artwork to life",
    icon: "📤",
    features: ["High-res uploads", "Vector support", "Multiple formats"],
  },
  {
    title: "AI Design Tools",
    description: "AI-powered design assistance and generation",
    icon: "🤖",
    features: ["AI backgrounds", "Style transfer", "Auto-enhance"],
  },
  {
    title: "Professional Tools",
    description: "Advanced editing and design capabilities",
    icon: "🛠️",
    features: ["Layer management", "Advanced effects", "Color matching"],
  },
  {
    title: "Brand Kit",
    description: "Maintain consistent branding across designs",
    icon: "🎯",
    features: ["Brand colors", "Logo library", "Font sets"],
  },
]

const inspirationGallery = [
  {
    title: "Abstract Art",
    image: "https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=300&h=200&fit=crop",
    category: "Art",
  },
  {
    title: "Typography Design",
    image: "https://images.unsplash.com/photo-1586953208448-b95a79798f07?w=300&h=200&fit=crop",
    category: "Typography",
  },
  {
    title: "Nature Photography",
    image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=300&h=200&fit=crop",
    category: "Photography",
  },
  {
    title: "Geometric Patterns",
    image: "https://images.unsplash.com/photo-1557804506-669a67965ba0?w=300&h=200&fit=crop",
    category: "Patterns",
  },
]

export default function CustomArtPage() {
  return (
    <div className="min-h-screen bg-white">
      <CategoryHero
        title="Custom Art Studio"
        description="Unlimited creative freedom with professional design tools"
        image="https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=800&h=400&fit=crop"
      />

      {/* Design Features */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-black mb-4">Professional Design Features</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Access to premium Canva features and tools for unlimited creative possibilities
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {customDesignFeatures.map((feature, index) => (
              <Card key={index} className="border-2 border-gray-200 hover:border-black transition-colors">
                <CardHeader className="text-center">
                  <div className="text-4xl mb-4">{feature.icon}</div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">{feature.description}</p>
                  <ul className="space-y-2">
                    {feature.features.map((item, idx) => (
                      <li key={idx} className="flex items-center text-sm">
                        <Sparkles className="h-4 w-4 text-purple-500 mr-2" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Inspiration Gallery */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-black mb-4">Design Inspiration</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Get inspired by these design styles and create something unique
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {inspirationGallery.map((item, index) => (
              <Card
                key={index}
                className="border-2 border-gray-200 hover:border-black transition-colors cursor-pointer group"
              >
                <CardContent className="p-0">
                  <div className="relative overflow-hidden">
                    <img
                      src={item.image || "/placeholder.svg"}
                      alt={item.title}
                      className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                      <Button variant="secondary" size="sm">
                        Use as Template
                      </Button>
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="font-bold">{item.title}</h3>
                    <p className="text-sm text-gray-600">{item.category}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Start Designing CTA */}
      <section className="py-16 bg-black text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Create?</h2>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Access our full-featured design studio powered by Canva Pro with unlimited creative possibilities
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-white text-black hover:bg-gray-100">
              <Palette className="mr-2 h-5 w-5" />
              Start from Scratch
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-black bg-transparent"
            >
              <Upload className="mr-2 h-5 w-5" />
              Upload Your Design
            </Button>
          </div>
        </div>
      </section>

      {/* Canva Design Studio */}
      <CanvaDesignStudio category="custom" products={[]} designType="custom-art" />
    </div>
  )
}
