"use client"

import { CanvaDesignStudio } from "@/components/canva-design-studio"
import { CategoryHero } from "@/components/category-hero"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Zap } from "lucide-react"

const apparelProducts = [
  {
    id: "app_tshirt",
    name: "Premium T-Shirt",
    price: 299,
    image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=300&h=300&fit=crop",
    canvaTemplateId: "tshirt-basic",
    printAreas: ["front", "back"],
  },
  {
    id: "app_hoodie",
    name: "Pullover Hoodie",
    price: 699,
    image: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=300&h=300&fit=crop",
    canvaTemplateId: "hoodie-basic",
    printAreas: ["front", "back", "sleeves"],
  },
  {
    id: "app_tank",
    name: "Tank Top",
    price: 249,
    image: "https://images.unsplash.com/photo-1618354691373-d851c5c3a990?w=300&h=300&fit=crop",
    canvaTemplateId: "tank-basic",
    printAreas: ["front", "back"],
  },
  {
    id: "app_longsleeve",
    name: "Long Sleeve Shirt",
    price: 399,
    image: "https://images.unsplash.com/photo-1571945153237-4929e783af4a?w=300&h=300&fit=crop",
    canvaTemplateId: "longsleeve-basic",
    printAreas: ["front", "back", "sleeves"],
  },
]

const designEssentials = [
  {
    title: "Typography",
    description: "Bold fonts and text effects for impactful designs",
    icon: "🔤",
    features: ["Premium fonts", "Text effects", "Custom lettering"],
  },
  {
    title: "Graphics",
    description: "Millions of design elements and illustrations",
    icon: "🎨",
    features: ["Vector graphics", "Icons", "Illustrations"],
  },
  {
    title: "Photos",
    description: "High-quality stock photos for your designs",
    icon: "📸",
    features: ["Stock photos", "Backgrounds", "Textures"],
  },
  {
    title: "Templates",
    description: "Pre-designed templates for quick customization",
    icon: "📋",
    features: ["Apparel templates", "Brand kits", "Style guides"],
  },
]

export default function ApparelDesignPage() {
  return (
    <div className="min-h-screen bg-white">
      <CategoryHero
        title="Apparel Design Studio"
        description="Create stunning custom apparel with professional design tools"
        image="https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=800&h=400&fit=crop"
      />

      {/* Design Essentials */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-black mb-4">Design Essentials</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Everything you need to create professional apparel designs with our Canva-powered design studio
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {designEssentials.map((essential, index) => (
              <Card key={index} className="border-2 border-gray-200 hover:border-black transition-colors">
                <CardHeader className="text-center">
                  <div className="text-4xl mb-4">{essential.icon}</div>
                  <CardTitle className="text-xl">{essential.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">{essential.description}</p>
                  <ul className="space-y-2">
                    {essential.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center text-sm">
                        <Zap className="h-4 w-4 text-green-500 mr-2" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Product Selection */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-black mb-8 text-center">Choose Your Apparel</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {apparelProducts.map((product) => (
              <Card
                key={product.id}
                className="border-2 border-gray-200 hover:border-black transition-colors cursor-pointer"
              >
                <CardContent className="p-4">
                  <img
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    className="w-full h-48 object-cover rounded mb-4"
                  />
                  <h3 className="font-bold text-lg mb-2">{product.name}</h3>
                  <p className="text-2xl font-bold text-black mb-2">R{product.price}</p>
                  <div className="flex flex-wrap gap-1">
                    {product.printAreas.map((area) => (
                      <span key={area} className="px-2 py-1 bg-gray-100 text-xs rounded">
                        {area}
                      </span>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Canva Design Studio */}
      <CanvaDesignStudio category="apparel" products={apparelProducts} designType="clothing" />
    </div>
  )
}
