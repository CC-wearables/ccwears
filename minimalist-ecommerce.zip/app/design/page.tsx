"use client"
import { Card, CardContent } from "@/components/ui/card"
import { useToast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"
import { CanvaDesignStudio } from "@/components/canva-design-studio"

const baseProducts = [
  {
    id: "tshirt",
    name: "T-Shirt",
    price: 299,
    image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=300&h=300&fit=crop",
    printAreas: ["front", "back"],
  },
  {
    id: "hoodie",
    name: "Hoodie",
    price: 699,
    image: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=300&h=300&fit=crop",
    printAreas: ["front", "back", "sleeves"],
  },
  {
    id: "mug",
    name: "Coffee Mug",
    price: 149,
    image: "https://images.unsplash.com/photo-1514228742587-6b1558fcf93a?w=300&h=300&fit=crop",
    printAreas: ["wrap-around"],
  },
  {
    id: "phone-case",
    name: "Phone Case",
    price: 199,
    image: "https://images.unsplash.com/photo-1601593346740-925612772716?w=300&h=300&fit=crop",
    printAreas: ["back"],
  },
  {
    id: "poster",
    name: "Poster",
    price: 249,
    image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=300&h=300&fit=crop",
    printAreas: ["full"],
  },
  {
    id: "tote-bag",
    name: "Tote Bag",
    price: 199,
    image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=300&h=300&fit=crop",
    printAreas: ["front", "back"],
  },
]

export default function DesignStudioPage() {
  const { toast } = useToast()
  const router = useRouter()

  return (
    <div className="min-h-screen bg-white py-8">
      <div className="container mx-auto px-4">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-black mb-4">Design Studio</h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Create your unique design with real-time preview and automatic saving. Drag, resize, and customize elements
            instantly.
          </p>
        </div>

        {/* Enhanced Canva Design Studio */}
        <CanvaDesignStudio category="general" products={baseProducts} designType="custom" />

        {/* Quick Start Tips */}
        <div className="mt-12 grid md:grid-cols-3 gap-6">
          <Card className="border-2 border-green-200 bg-green-50">
            <CardContent className="p-6 text-center">
              <div className="text-3xl mb-4">🎨</div>
              <h3 className="font-bold mb-2">Real-Time Design</h3>
              <p className="text-sm text-gray-600">
                See your changes instantly as you design. No waiting, no reloading.
              </p>
            </CardContent>
          </Card>
          <Card className="border-2 border-blue-200 bg-blue-50">
            <CardContent className="p-6 text-center">
              <div className="text-3xl mb-4">💾</div>
              <h3 className="font-bold mb-2">Auto-Save</h3>
              <p className="text-sm text-gray-600">
                Your designs are automatically saved every second. Never lose your work.
              </p>
            </CardContent>
          </Card>
          <Card className="border-2 border-purple-200 bg-purple-50">
            <CardContent className="p-6 text-center">
              <div className="text-3xl mb-4">🖱️</div>
              <h3 className="font-bold mb-2">Easy Editing</h3>
              <p className="text-sm text-gray-600">Drag to move, click to select, use sliders to adjust properties.</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
