"use client"

import { CanvaDesignStudio } from "@/components/canva-design-studio"
import { CategoryHero } from "@/components/category-hero"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Zap } from "lucide-react"

const homeProducts = [
  {
    id: "home_mug",
    name: "Coffee Mug",
    price: 149,
    image: "https://images.unsplash.com/photo-1514228742587-6b1558fcf93a?w=300&h=300&fit=crop",
    canvaTemplateId: "mug-basic",
    printAreas: ["wrap-around"],
  },
  {
    id: "home_poster",
    name: "Art Poster",
    price: 249,
    image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=300&h=300&fit=crop",
    canvaTemplateId: "poster-basic",
    printAreas: ["full"],
  },
  {
    id: "home_canvas",
    name: "Canvas Print",
    price: 399,
    image: "https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=300&h=300&fit=crop",
    canvaTemplateId: "canvas-basic",
    printAreas: ["full"],
  },
  {
    id: "home_pillow",
    name: "Throw Pillow",
    price: 299,
    image: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=300&h=300&fit=crop",
    canvaTemplateId: "pillow-basic",
    printAreas: ["front", "back"],
  },
]

const designEssentials = [
  {
    title: "Home Decor",
    description: "Elements perfect for home and office spaces",
    icon: "🏠",
    features: ["Interior themes", "Color palettes", "Decor elements"],
  },
  {
    title: "Typography",
    description: "Elegant fonts for quotes and sayings",
    icon: "📝",
    features: ["Script fonts", "Modern typography", "Quote layouts"],
  },
  {
    title: "Artwork",
    description: "Artistic elements and illustrations",
    icon: "🎨",
    features: ["Abstract art", "Nature themes", "Minimalist designs"],
  },
  {
    title: "Photography",
    description: "High-quality photos for stunning prints",
    icon: "📷",
    features: ["Landscape photos", "Abstract photography", "Lifestyle images"],
  },
]

export default function HomeDesignPage() {
  return (
    <div className="min-h-screen bg-white">
      <CategoryHero
        title="Home & Office Design Studio"
        description="Create beautiful home decor and office accessories"
        image="https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=800&h=400&fit=crop"
      />

      {/* Design Essentials */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-black mb-4">Design Essentials</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Curated design elements perfect for home and office environments
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {designEssentials.map((essential, index) => (
              <Card key={index} className="border-2 border-gray-200 hover:border-black transition-colors">
                <CardHeader className="text-center">
                  <div className="text-4xl mb-4">{essential.icon}</div>
                  <CardTitle className="text-xl">{essential.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">{essential.description}</p>
                  <ul className="space-y-2">
                    {essential.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center text-sm">
                        <Zap className="h-4 w-4 text-green-500 mr-2" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Product Selection */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-black mb-8 text-center">Choose Your Product</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {homeProducts.map((product) => (
              <Card
                key={product.id}
                className="border-2 border-gray-200 hover:border-black transition-colors cursor-pointer"
              >
                <CardContent className="p-4">
                  <img
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    className="w-full h-48 object-cover rounded mb-4"
                  />
                  <h3 className="font-bold text-lg mb-2">{product.name}</h3>
                  <p className="text-2xl font-bold text-black mb-2">R{product.price}</p>
                  <div className="flex flex-wrap gap-1">
                    {product.printAreas.map((area) => (
                      <span key={area} className="px-2 py-1 bg-gray-100 text-xs rounded">
                        {area}
                      </span>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Canva Design Studio */}
      <CanvaDesignStudio category="home" products={homeProducts} designType="home-office" />
    </div>
  )
}
