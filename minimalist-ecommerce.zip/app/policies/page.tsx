export default function PoliciesPage() {
  return (
    <div className="min-h-screen bg-white py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        <h1 className="text-4xl font-bold text-black mb-8">Policies</h1>

        <div className="space-y-12">
          <section id="shipping">
            <h2 className="text-2xl font-bold text-black mb-6">Shipping Policy</h2>
            <div className="prose prose-lg max-w-none">
              <h3 className="text-xl font-semibold mb-4">Shipping Options & Costs</h3>
              <div className="bg-gray-50 p-6 rounded-lg mb-6">
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="text-center">
                    <h4 className="font-bold mb-2">Standard Delivery</h4>
                    <p className="text-2xl font-bold text-black mb-2">R50</p>
                    <p className="text-sm text-gray-600">5-7 business days</p>
                    <p className="text-xs text-green-600 mt-2">FREE on orders over R500</p>
                  </div>
                  <div className="text-center">
                    <h4 className="font-bold mb-2">Express Delivery</h4>
                    <p className="text-2xl font-bold text-black mb-2">R100</p>
                    <p className="text-sm text-gray-600">2-3 business days</p>
                  </div>
                  <div className="text-center">
                    <h4 className="font-bold mb-2">Overnight Delivery</h4>
                    <p className="text-2xl font-bold text-black mb-2">R200</p>
                    <p className="text-sm text-gray-600">1 business day</p>
                  </div>
                </div>
              </div>

              <h3 className="text-xl font-semibold mb-4">Processing Times</h3>
              <ul className="list-disc pl-6 space-y-2">
                <li>
                  <strong>Electronics:</strong> 1-2 business days processing
                </li>
                <li>
                  <strong>Clothing:</strong> 1-3 business days processing
                </li>
                <li>
                  <strong>Print on Demand:</strong> 3-5 business days processing (custom items)
                </li>
              </ul>

              <h3 className="text-xl font-semibold mb-4 mt-6">Delivery Areas</h3>
              <p>
                We currently deliver nationwide within South Africa. International shipping is not available at this
                time.
              </p>
            </div>
          </section>

          <section id="returns">
            <h2 className="text-2xl font-bold text-black mb-6">Return & Refund Policy</h2>
            <div className="prose prose-lg max-w-none">
              <h3 className="text-xl font-semibold mb-4">30-Day Return Policy</h3>
              <p className="mb-4">
                We offer a 30-day return policy from the date of delivery. Items must be in original condition, unworn,
                unused, and in original packaging.
              </p>

              <h3 className="text-xl font-semibold mb-4">Return Process</h3>
              <ol className="list-decimal pl-6 space-y-2">
                <li>Contact our support team within 30 days of delivery</li>
                <li>Receive return authorization and shipping label</li>
                <li>Package items securely and ship back to us</li>
                <li>Refund processed within 5-7 business days after we receive your return</li>
              </ol>

              <h3 className="text-xl font-semibold mb-4 mt-6">Non-Returnable Items</h3>
              <ul className="list-disc pl-6 space-y-2">
                <li>Custom print-on-demand items (unless defective)</li>
                <li>Items damaged by misuse</li>
                <li>Items returned after 30 days</li>
              </ul>

              <h3 className="text-xl font-semibold mb-4 mt-6">Refund Methods</h3>
              <p>
                Refunds will be processed to the original payment method. Please allow 5-10 business days for the refund
                to appear in your account.
              </p>
            </div>
          </section>

          <section id="privacy">
            <h2 className="text-2xl font-bold text-black mb-6">Privacy Policy</h2>
            <div className="prose prose-lg max-w-none">
              <h3 className="text-xl font-semibold mb-4">Information We Collect</h3>
              <ul className="list-disc pl-6 space-y-2">
                <li>Personal information (name, email, address, phone)</li>
                <li>Payment information (processed securely through our payment partners)</li>
                <li>Order history and preferences</li>
                <li>Website usage data and analytics</li>
              </ul>

              <h3 className="text-xl font-semibold mb-4 mt-6">How We Use Your Information</h3>
              <ul className="list-disc pl-6 space-y-2">
                <li>Process and fulfill your orders</li>
                <li>Communicate about your orders and account</li>
                <li>Improve our products and services</li>
                <li>Send promotional emails (with your consent)</li>
              </ul>

              <h3 className="text-xl font-semibold mb-4 mt-6">Data Security</h3>
              <p>
                We implement industry-standard security measures to protect your personal information. Your payment data
                is encrypted and processed through secure payment gateways.
              </p>
            </div>
          </section>

          <section id="terms">
            <h2 className="text-2xl font-bold text-black mb-6">Terms of Service</h2>
            <div className="prose prose-lg max-w-none">
              <h3 className="text-xl font-semibold mb-4">Acceptance of Terms</h3>
              <p className="mb-4">
                By using our website and services, you agree to these terms and conditions. If you do not agree, please
                do not use our services.
              </p>

              <h3 className="text-xl font-semibold mb-4">Product Information</h3>
              <p className="mb-4">
                We strive to provide accurate product descriptions and images. However, we do not guarantee that colors,
                textures, or other details will be exactly as displayed on your screen.
              </p>

              <h3 className="text-xl font-semibold mb-4">Pricing</h3>
              <p className="mb-4">
                All prices are listed in South African Rand (ZAR) and include VAT where applicable. We reserve the right
                to change prices without notice.
              </p>

              <h3 className="text-xl font-semibold mb-4">Limitation of Liability</h3>
              <p className="mb-4">
                Our liability is limited to the purchase price of the product. We are not responsible for any indirect,
                incidental, or consequential damages.
              </p>
            </div>
          </section>
        </div>

        <div className="mt-12 p-6 bg-black text-white rounded-lg">
          <h3 className="text-xl font-bold mb-4">Contact Us</h3>
          <p className="mb-2">If you have any questions about these policies, please contact us:</p>
          <ul className="space-y-1">
            <li>Email: support@minimalstore.co.za</li>
            <li>Phone: +27 11 123 4567</li>
            <li>Address: 123 Main Street, Johannesburg, 2000</li>
          </ul>
        </div>
      </div>
    </div>
  )
}
