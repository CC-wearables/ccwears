"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ProductGrid } from "@/components/product-grid"
import { useToast } from "@/hooks/use-toast"
import { TrendingUp, Zap, Clock, Target, RefreshCw } from "lucide-react"
import { getAISystem, type TrendingProduct } from "@/lib/ai-automation"

export default function TrendingPage() {
  const [trendingProducts, setTrendingProducts] = useState<TrendingProduct[]>([])
  const [loading, setLoading] = useState(true)
  const [lastUpdate, setLastUpdate] = useState<string>("")
  const { toast } = useToast()

  const aiSystem = getAISystem()

  useEffect(() => {
    loadTrendingProducts()

    // Auto-refresh every 30 minutes
    const interval = setInterval(loadTrendingProducts, 30 * 60 * 1000)
    return () => clearInterval(interval)
  }, [])

  const loadTrendingProducts = async () => {
    try {
      setLoading(true)

      // Load from localStorage first
      const savedProducts = localStorage.getItem("trending_products")
      if (savedProducts) {
        const products = JSON.parse(savedProducts)
        setTrendingProducts(products)
        setLastUpdate(new Date().toLocaleString())
      }

      // Fetch fresh data
      const freshProducts = await aiSystem.discoverTrendingProducts()
      if (freshProducts.length > 0) {
        setTrendingProducts(freshProducts)
        localStorage.setItem("trending_products", JSON.stringify(freshProducts))
        setLastUpdate(new Date().toLocaleString())
      }
    } catch (error) {
      toast({
        title: "Error loading trending products",
        description: "Using cached data",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const refreshTrends = async () => {
    toast({
      title: "Refreshing trends...",
      description: "AI is analyzing latest social media data",
    })
    await loadTrendingProducts()
  }

  // Convert trending products to product grid format
  const productGridItems = trendingProducts.map((product) => ({
    id: product.id,
    name: product.name,
    price: product.suggestedPrice,
    category: product.category,
    image: product.image,
    description: product.description,
    trendScore: product.trendScore,
    sources: product.sources,
    hashtags: product.hashtags,
  }))

  return (
    <div className="min-h-screen bg-white py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <TrendingUp className="h-12 w-12 text-red-500 mr-4" />
            <h1 className="text-4xl font-bold text-black">Trending Products</h1>
          </div>
          <p className="text-gray-600 max-w-2xl mx-auto mb-6">
            AI-powered discovery of viral products trending on TikTok, Instagram, and Facebook. Updated automatically
            every 6 hours with the latest South African trends.
          </p>
          <div className="flex items-center justify-center space-x-4">
            <Badge variant="secondary" className="bg-red-100 text-red-800">
              <Zap className="w-3 h-3 mr-1" />
              AI Powered
            </Badge>
            <Badge variant="secondary" className="bg-blue-100 text-blue-800">
              <Clock className="w-3 h-3 mr-1" />
              Last updated: {lastUpdate}
            </Badge>
            <Button onClick={refreshTrends} variant="outline" size="sm">
              <RefreshCw className="w-4 h-4 mr-2" />
              Refresh
            </Button>
          </div>
        </div>

        {/* Trending Stats */}
        <div className="grid md:grid-cols-4 gap-6 mb-12">
          <Card className="border-2 border-red-200 bg-red-50">
            <CardContent className="p-6 text-center">
              <TrendingUp className="h-8 w-8 mx-auto mb-2 text-red-500" />
              <h3 className="font-bold text-2xl text-red-600">{Math.min(trendingProducts.length, 20)}</h3>
              <p className="text-sm text-red-800">Trending Items</p>
            </CardContent>
          </Card>

          <Card className="border-2 border-blue-200 bg-blue-50">
            <CardContent className="p-6 text-center">
              <Target className="h-8 w-8 mx-auto mb-2 text-blue-500" />
              <h3 className="font-bold text-2xl text-blue-600">
                {Math.round(trendingProducts.reduce((sum, p) => sum + p.trendScore, 0) / trendingProducts.length) || 0}
              </h3>
              <p className="text-sm text-blue-800">Avg Trend Score</p>
            </CardContent>
          </Card>

          <Card className="border-2 border-green-200 bg-green-50">
            <CardContent className="p-6 text-center">
              <Zap className="h-8 w-8 mx-auto mb-2 text-green-500" />
              <h3 className="font-bold text-2xl text-green-600">
                {trendingProducts.reduce((sum, p) => sum + p.estimatedDemand, 0).toLocaleString()}
              </h3>
              <p className="text-sm text-green-800">Total Demand</p>
            </CardContent>
          </Card>

          <Card className="border-2 border-purple-200 bg-purple-50">
            <CardContent className="p-6 text-center">
              <div className="text-2xl mb-2">🔥</div>
              <h3 className="font-bold text-2xl text-purple-600">
                {trendingProducts.filter((p) => p.trendScore > 90).length}
              </h3>
              <p className="text-sm text-purple-800">Viral Products</p>
            </CardContent>
          </Card>
        </div>

        {/* Trending Products Grid */}
        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-500 mx-auto mb-4"></div>
            <p className="text-gray-600">AI is analyzing trending products...</p>
          </div>
        ) : trendingProducts.length > 0 ? (
          <>
            <div className="mb-8">
              <h2 className="text-3xl font-bold text-black mb-4">🔥 Viral Right Now</h2>
              <p className="text-gray-600">These products are trending across social media platforms in South Africa</p>
            </div>
            <ProductGrid products={productGridItems.slice(0, 20)} />
          </>
        ) : (
          <Card className="border-2 border-gray-200">
            <CardContent className="p-12 text-center">
              <TrendingUp className="h-16 w-16 mx-auto mb-4 text-gray-400" />
              <h3 className="text-xl font-bold mb-2">No trending products found</h3>
              <p className="text-gray-600 mb-4">Our AI is currently analyzing social media trends. Check back soon!</p>
              <Button onClick={refreshTrends}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh Trends
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
