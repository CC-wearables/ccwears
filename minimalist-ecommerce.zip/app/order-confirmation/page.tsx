import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle, Package, Truck } from "lucide-react"
import Link from "next/link"

export default function OrderConfirmationPage() {
  return (
    <div className="min-h-screen bg-white py-16">
      <div className="container mx-auto px-4 max-w-2xl text-center">
        <div className="mb-8">
          <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
          <h1 className="text-4xl font-bold text-black mb-4">Order Confirmed!</h1>
          <p className="text-gray-600 text-lg">Thank you for your purchase. Your order has been successfully placed.</p>
        </div>

        <Card className="border-2 border-green-500 mb-8">
          <CardHeader>
            <CardTitle className="text-green-700">Order Details</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="font-medium">Order Number:</span>
                <span className="font-bold">#MIN-{Math.random().toString(36).substr(2, 9).toUpperCase()}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="font-medium">Estimated Delivery:</span>
                <span>5-7 business days</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="font-medium">Email Confirmation:</span>
                <span>Sent to your email address</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <Card className="border-2 border-gray-200">
            <CardContent className="p-6 text-center">
              <Package className="h-8 w-8 mx-auto mb-3 text-gray-600" />
              <h3 className="font-bold mb-2">Processing</h3>
              <p className="text-sm text-gray-600">Your order is being prepared for shipment</p>
            </CardContent>
          </Card>

          <Card className="border-2 border-gray-200">
            <CardContent className="p-6 text-center">
              <Truck className="h-8 w-8 mx-auto mb-3 text-gray-600" />
              <h3 className="font-bold mb-2">Tracking</h3>
              <p className="text-sm text-gray-600">You'll receive tracking info via email</p>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-4">
          <Button asChild className="w-full bg-black text-white hover:bg-gray-800">
            <Link href="/catalog">Continue Shopping</Link>
          </Button>
          <Button
            asChild
            variant="outline"
            className="w-full border-black text-black hover:bg-black hover:text-white bg-transparent"
          >
            <Link href="/">Return to Home</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
