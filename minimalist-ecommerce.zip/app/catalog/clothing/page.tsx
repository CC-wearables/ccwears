"use client"

import { Label } from "@/components/ui/label"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Star, Heart, Share2, ShoppingCart, Grid, List } from "lucide-react"
import { useCart } from "@/components/cart-provider"
import { useToast } from "@/hooks/use-toast"

const clothingProducts = [
  {
    id: "cloth_001",
    name: "Premium Cotton T-Shirt",
    description: "Soft, breathable cotton t-shirt perfect for everyday wear. Classic fit with modern styling.",
    price: 299,
    originalPrice: 399,
    image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400&h=400&fit=crop",
    rating: 4.7,
    reviews: 234,
    stock: "In Stock",
    stockLevel: 89,
    category: "T-Shirts",
    sizes: ["XS", "S", "M", "L", "XL", "XXL"],
    colors: ["White", "Black", "Navy", "Gray", "Red"],
    material: "100% Premium Cotton",
    care: "Machine wash cold, tumble dry low",
    fit: "Classic Fit",
    badges: ["Bestseller", "Eco-Friendly"],
  },
  {
    id: "cloth_002",
    name: "Slim Fit Denim Jeans",
    description: "Modern slim-fit jeans with stretch comfort. Perfect for casual and smart-casual occasions.",
    price: 899,
    originalPrice: 1199,
    image: "https://images.unsplash.com/photo-1542272604-787c3835535d?w=400&h=400&fit=crop",
    rating: 4.5,
    reviews: 167,
    stock: "In Stock",
    stockLevel: 45,
    category: "Jeans",
    sizes: ["28", "30", "32", "34", "36", "38", "40"],
    colors: ["Dark Blue", "Light Blue", "Black", "Gray"],
    material: "98% Cotton, 2% Elastane",
    care: "Machine wash inside out, hang dry",
    fit: "Slim Fit",
    badges: ["Classic", "Stretch"],
  },
  {
    id: "cloth_003",
    name: "Athletic Performance Hoodie",
    description: "Moisture-wicking hoodie designed for active lifestyles. Lightweight yet warm.",
    price: 699,
    originalPrice: 899,
    image: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=400&h=400&fit=crop",
    rating: 4.8,
    reviews: 312,
    stock: "Low Stock",
    stockLevel: 12,
    category: "Hoodies",
    sizes: ["S", "M", "L", "XL", "XXL"],
    colors: ["Black", "Gray", "Navy", "Forest Green"],
    material: "Polyester Blend with Moisture-Wicking",
    care: "Machine wash cold, do not bleach",
    fit: "Athletic Fit",
    badges: ["Athletic", "Moisture-Wicking"],
  },
  {
    id: "cloth_004",
    name: "Business Casual Polo Shirt",
    description: "Professional polo shirt suitable for office and casual settings. Wrinkle-resistant fabric.",
    price: 449,
    originalPrice: 599,
    image: "https://images.unsplash.com/photo-1586790170083-2f9ceadc732d?w=400&h=400&fit=crop",
    rating: 4.4,
    reviews: 189,
    stock: "In Stock",
    stockLevel: 67,
    category: "Polo Shirts",
    sizes: ["S", "M", "L", "XL", "XXL"],
    colors: ["White", "Navy", "Light Blue", "Burgundy"],
    material: "Cotton-Polyester Blend",
    care: "Machine wash warm, iron if needed",
    fit: "Regular Fit",
    badges: ["Professional", "Wrinkle-Resistant"],
  },
  {
    id: "cloth_005",
    name: "Casual Summer Shorts",
    description: "Comfortable cotton shorts perfect for warm weather. Multiple pockets and adjustable waist.",
    price: 349,
    originalPrice: 449,
    image: "https://images.unsplash.com/photo-1591195853828-11db59a44f6b?w=400&h=400&fit=crop",
    rating: 4.3,
    reviews: 145,
    stock: "In Stock",
    stockLevel: 78,
    category: "Shorts",
    sizes: ["S", "M", "L", "XL", "XXL"],
    colors: ["Khaki", "Navy", "Olive", "Black"],
    material: "100% Cotton Canvas",
    care: "Machine wash cold, air dry",
    fit: "Relaxed Fit",
    badges: ["Summer", "Comfortable"],
  },
  {
    id: "cloth_006",
    name: "Formal Button-Down Shirt",
    description: "Crisp, professional button-down shirt for business and formal occasions. Non-iron fabric.",
    price: 599,
    originalPrice: 799,
    image: "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=400&h=400&fit=crop",
    rating: 4.6,
    reviews: 203,
    stock: "In Stock",
    stockLevel: 34,
    category: "Dress Shirts",
    sizes: ["S", "M", "L", "XL", "XXL"],
    colors: ["White", "Light Blue", "Pink", "Lavender"],
    material: "Cotton-Polyester Non-Iron Blend",
    care: "Machine wash warm, minimal ironing needed",
    fit: "Tailored Fit",
    badges: ["Formal", "Non-Iron"],
  },
]

const shippingOptions = [
  { id: "standard", name: "Standard Shipping", price: 50, time: "3-5 business days" },
  { id: "express", name: "Express Shipping", price: 100, time: "1-2 business days" },
  { id: "overnight", name: "Overnight Shipping", price: 200, time: "Next day delivery" },
]

export default function ClothingPage() {
  const [sortBy, setSortBy] = useState("featured")
  const [viewMode, setViewMode] = useState("grid")
  const [selectedShipping, setSelectedShipping] = useState("standard")
  const [selectedSizes, setSelectedSizes] = useState<{ [key: string]: string }>({})
  const [selectedColors, setSelectedColors] = useState<{ [key: string]: string }>({})
  const { addItem } = useCart()
  const { toast } = useToast()

  const handleAddToCart = (product: any) => {
    const size = selectedSizes[product.id] || product.sizes[0]
    const color = selectedColors[product.id] || product.colors[0]
    const shippingOption = shippingOptions.find((s) => s.id === selectedShipping)

    addItem({
      id: product.id,
      name: `${product.name} (${size}, ${color})`,
      price: product.price,
      image: product.image,
      quantity: 1,
      shipping: shippingOption,
      options: { size, color },
    })

    toast({
      title: "Added to Cart",
      description: `${product.name} in ${size}/${color} has been added to your cart`,
    })
  }

  const sortedProducts = [...clothingProducts].sort((a, b) => {
    switch (sortBy) {
      case "price-low":
        return a.price - b.price
      case "price-high":
        return b.price - a.price
      case "rating":
        return b.rating - a.rating
      case "newest":
        return new Date().getTime() - new Date().getTime()
      default:
        return 0
    }
  })

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-black mb-4">Clothing</h1>
          <p className="text-gray-600 text-lg">Discover stylish and comfortable clothing for every occasion</p>
        </div>

        {/* Controls */}
        <div className="flex flex-wrap items-center justify-between mb-8 gap-4">
          <div className="flex items-center space-x-4">
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="featured">Featured</SelectItem>
                <SelectItem value="price-low">Price: Low to High</SelectItem>
                <SelectItem value="price-high">Price: High to Low</SelectItem>
                <SelectItem value="rating">Highest Rated</SelectItem>
                <SelectItem value="newest">Newest</SelectItem>
              </SelectContent>
            </Select>

            <Select value={selectedShipping} onValueChange={setSelectedShipping}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Shipping Option" />
              </SelectTrigger>
              <SelectContent>
                {shippingOptions.map((option) => (
                  <SelectItem key={option.id} value={option.id}>
                    {option.name} - R{option.price} ({option.time})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center space-x-2">
            <Button variant={viewMode === "grid" ? "default" : "outline"} size="sm" onClick={() => setViewMode("grid")}>
              <Grid className="h-4 w-4" />
            </Button>
            <Button variant={viewMode === "list" ? "default" : "outline"} size="sm" onClick={() => setViewMode("list")}>
              <List className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Products Grid */}
        <div
          className={`grid gap-6 ${viewMode === "grid" ? "grid-cols-1 md:grid-cols-2 lg:grid-cols-3" : "grid-cols-1"}`}
        >
          {sortedProducts.map((product) => (
            <Card key={product.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="relative">
                <img
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  className="w-full h-64 object-cover"
                />
                <div className="absolute top-4 left-4 flex flex-wrap gap-2">
                  {product.badges.map((badge) => (
                    <Badge key={badge} variant="secondary" className="bg-black text-white">
                      {badge}
                    </Badge>
                  ))}
                </div>
                <div className="absolute top-4 right-4 flex space-x-2">
                  <Button size="sm" variant="secondary" className="p-2">
                    <Heart className="h-4 w-4" />
                  </Button>
                  <Button size="sm" variant="secondary" className="p-2">
                    <Share2 className="h-4 w-4" />
                  </Button>
                </div>
                <div
                  className={`absolute bottom-4 right-4 px-2 py-1 rounded text-sm font-medium ${
                    product.stock === "In Stock"
                      ? "bg-green-100 text-green-800"
                      : product.stock === "Low Stock"
                        ? "bg-yellow-100 text-yellow-800"
                        : "bg-red-100 text-red-800"
                  }`}
                >
                  {product.stock}
                </div>
              </div>

              <CardContent className="p-6">
                <div className="mb-4">
                  <h3 className="text-xl font-semibold text-black mb-2">{product.name}</h3>
                  <p className="text-gray-600 text-sm mb-3">{product.description}</p>

                  <div className="flex items-center mb-3">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`h-4 w-4 ${
                            i < Math.floor(product.rating) ? "text-yellow-400 fill-current" : "text-gray-300"
                          }`}
                        />
                      ))}
                    </div>
                    <span className="ml-2 text-sm text-gray-600">
                      {product.rating} ({product.reviews} reviews)
                    </span>
                  </div>

                  <div className="flex items-center space-x-2 mb-4">
                    <span className="text-2xl font-bold text-black">R{product.price}</span>
                    {product.originalPrice > product.price && (
                      <>
                        <span className="text-lg text-gray-500 line-through">R{product.originalPrice}</span>
                        <Badge variant="destructive">Save R{product.originalPrice - product.price}</Badge>
                      </>
                    )}
                  </div>

                  {/* Size Selection */}
                  <div className="mb-4">
                    <Label className="text-sm font-semibold mb-2 block">Size:</Label>
                    <Select
                      value={selectedSizes[product.id] || product.sizes[0]}
                      onValueChange={(size) => setSelectedSizes((prev) => ({ ...prev, [product.id]: size }))}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {product.sizes.map((size) => (
                          <SelectItem key={size} value={size}>
                            {size}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Color Selection */}
                  <div className="mb-4">
                    <Label className="text-sm font-semibold mb-2 block">Color:</Label>
                    <Select
                      value={selectedColors[product.id] || product.colors[0]}
                      onValueChange={(color) => setSelectedColors((prev) => ({ ...prev, [product.id]: color }))}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {product.colors.map((color) => (
                          <SelectItem key={color} value={color}>
                            {color}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {viewMode === "list" && (
                    <div className="mb-4 space-y-2">
                      <div className="text-sm">
                        <span className="text-gray-600">Material:</span>
                        <span className="ml-1 font-medium">{product.material}</span>
                      </div>
                      <div className="text-sm">
                        <span className="text-gray-600">Fit:</span>
                        <span className="ml-1 font-medium">{product.fit}</span>
                      </div>
                      <div className="text-sm">
                        <span className="text-gray-600">Care:</span>
                        <span className="ml-1 font-medium">{product.care}</span>
                      </div>
                    </div>
                  )}
                </div>

                <div className="space-y-3">
                  <div className="text-sm text-gray-600">
                    <strong>Shipping:</strong> {shippingOptions.find((s) => s.id === selectedShipping)?.name}
                    (+R{shippingOptions.find((s) => s.id === selectedShipping)?.price})
                  </div>

                  <Button
                    onClick={() => handleAddToCart(product)}
                    className="w-full bg-black text-white hover:bg-gray-800"
                    disabled={product.stock === "Out of Stock"}
                  >
                    <ShoppingCart className="mr-2 h-4 w-4" />
                    Add to Cart - R
                    {product.price + (shippingOptions.find((s) => s.id === selectedShipping)?.price || 0)}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Size Guide */}
        <div className="mt-12 p-6 bg-blue-50 border border-blue-200 rounded-lg">
          <h3 className="text-lg font-semibold text-blue-800 mb-4">Size Guide</h3>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold mb-2">Apparel Sizes (Chest/Bust)</h4>
              <div className="text-sm space-y-1">
                <div>XS: 32-34" | S: 34-36" | M: 36-38"</div>
                <div>L: 38-40" | XL: 40-42" | XXL: 42-44"</div>
              </div>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Jeans Sizes (Waist)</h4>
              <div className="text-sm space-y-1">
                <div>28: 28" | 30: 30" | 32: 32" | 34: 34"</div>
                <div>36: 36" | 38: 38" | 40: 40"</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
