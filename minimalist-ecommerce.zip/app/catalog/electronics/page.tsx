"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Star, Heart, Share2, ShoppingCart, Grid, List } from "lucide-react"
import { useCart } from "@/components/cart-provider"
import { useToast } from "@/hooks/use-toast"

const electronicsProducts = [
  {
    id: "elec_001",
    name: "Wireless Bluetooth Earbuds Pro",
    description: "Premium noise-cancelling earbuds with 30-hour battery life and crystal-clear sound quality.",
    price: 899,
    originalPrice: 1299,
    image: "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=400&h=400&fit=crop",
    rating: 4.8,
    reviews: 324,
    stock: "In Stock",
    stockLevel: 45,
    category: "Audio",
    features: ["Noise Cancellation", "30hr Battery", "Waterproof IPX7", "Quick Charge"],
    badges: ["Bestseller", "Premium"],
    specifications: {
      "Battery Life": "30 hours",
      Connectivity: "Bluetooth 5.3",
      "Water Resistance": "IPX7",
      "Driver Size": "12mm",
    },
  },
  {
    id: "elec_002",
    name: "Smart Fitness Watch Ultra",
    description: "Advanced fitness tracking with GPS, heart rate monitoring, and 7-day battery life.",
    price: 2499,
    originalPrice: 3199,
    image: "https://images.unsplash.com/photo-1544117519-31a4b719223d?w=400&h=400&fit=crop",
    rating: 4.6,
    reviews: 189,
    stock: "Low Stock",
    stockLevel: 8,
    category: "Wearables",
    features: ["GPS Tracking", "Heart Rate Monitor", "7-day Battery", "50+ Sports Modes"],
    badges: ["New", "Premium"],
    specifications: {
      Display: '1.4" AMOLED',
      Battery: "7 days",
      "Water Rating": "5ATM",
      Sensors: "GPS, Heart Rate, SpO2",
    },
  },
  {
    id: "elec_003",
    name: "Portable Power Bank 20000mAh",
    description: "High-capacity power bank with fast charging and multiple device support.",
    price: 449,
    originalPrice: 599,
    image: "https://images.unsplash.com/photo-1609592806596-4d8b5b5c5b5c?w=400&h=400&fit=crop",
    rating: 4.4,
    reviews: 567,
    stock: "In Stock",
    stockLevel: 120,
    category: "Accessories",
    features: ["20000mAh Capacity", "Fast Charge 22.5W", "3 USB Ports", "LED Display"],
    badges: ["Value"],
    specifications: {
      Capacity: "20000mAh",
      Output: "22.5W Fast Charge",
      Ports: "3x USB, 1x USB-C",
      Weight: "420g",
    },
  },
  {
    id: "elec_004",
    name: "4K Webcam with Auto Focus",
    description: "Professional 4K webcam with auto-focus, noise reduction, and wide-angle lens.",
    price: 1299,
    originalPrice: 1699,
    image: "https://images.unsplash.com/photo-1587825140708-dfaf72ae4b04?w=400&h=400&fit=crop",
    rating: 4.7,
    reviews: 203,
    stock: "In Stock",
    stockLevel: 32,
    category: "Computing",
    features: ["4K Resolution", "Auto Focus", "Noise Reduction", "Wide Angle 90°"],
    badges: ["Professional"],
    specifications: {
      Resolution: "4K @ 30fps",
      "Field of View": "90° diagonal",
      Focus: "Auto focus",
      Microphone: "Dual stereo",
    },
  },
  {
    id: "elec_005",
    name: "RGB Gaming Keyboard Mechanical",
    description: "Mechanical gaming keyboard with RGB backlighting and programmable keys.",
    price: 899,
    originalPrice: 1199,
    image: "https://images.unsplash.com/photo-1541140532154-b024d705b90a?w=400&h=400&fit=crop",
    rating: 4.5,
    reviews: 445,
    stock: "In Stock",
    stockLevel: 67,
    category: "Gaming",
    features: ["Mechanical Switches", "RGB Backlighting", "Programmable Keys", "Anti-Ghosting"],
    badges: ["Gaming"],
    specifications: {
      "Switch Type": "Blue Mechanical",
      Backlighting: "RGB",
      Layout: "Full Size",
      Connection: "USB-C",
    },
  },
  {
    id: "elec_006",
    name: "Wireless Charging Pad 15W",
    description: "Fast wireless charging pad compatible with all Qi-enabled devices.",
    price: 299,
    originalPrice: 399,
    image: "https://images.unsplash.com/photo-1586953208448-b95a79798f07?w=400&h=400&fit=crop",
    rating: 4.3,
    reviews: 789,
    stock: "In Stock",
    stockLevel: 156,
    category: "Accessories",
    features: ["15W Fast Charging", "Qi Compatible", "LED Indicator", "Non-Slip Base"],
    badges: ["Eco-Friendly"],
    specifications: {
      "Power Output": "15W Max",
      Compatibility: "Qi-enabled devices",
      Dimensions: "100mm diameter",
      Cable: "1.2m USB-C",
    },
  },
]

const shippingOptions = [
  { id: "standard", name: "Standard Shipping", price: 50, time: "3-5 business days" },
  { id: "express", name: "Express Shipping", price: 100, time: "1-2 business days" },
  { id: "overnight", name: "Overnight Shipping", price: 200, time: "Next day delivery" },
]

export default function ElectronicsPage() {
  const [sortBy, setSortBy] = useState("featured")
  const [viewMode, setViewMode] = useState("grid")
  const [selectedShipping, setSelectedShipping] = useState("standard")
  const { addItem } = useCart()
  const { toast } = useToast()

  const handleAddToCart = (product: any) => {
    const shippingOption = shippingOptions.find((s) => s.id === selectedShipping)
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      quantity: 1,
      shipping: shippingOption,
    })

    toast({
      title: "Added to Cart",
      description: `${product.name} has been added to your cart with ${shippingOption?.name}`,
    })
  }

  const sortedProducts = [...electronicsProducts].sort((a, b) => {
    switch (sortBy) {
      case "price-low":
        return a.price - b.price
      case "price-high":
        return b.price - a.price
      case "rating":
        return b.rating - a.rating
      case "newest":
        return new Date().getTime() - new Date().getTime()
      default:
        return 0
    }
  })

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-black mb-4">Electronics</h1>
          <p className="text-gray-600 text-lg">Discover the latest in technology and electronics</p>
        </div>

        {/* Controls */}
        <div className="flex flex-wrap items-center justify-between mb-8 gap-4">
          <div className="flex items-center space-x-4">
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="featured">Featured</SelectItem>
                <SelectItem value="price-low">Price: Low to High</SelectItem>
                <SelectItem value="price-high">Price: High to Low</SelectItem>
                <SelectItem value="rating">Highest Rated</SelectItem>
                <SelectItem value="newest">Newest</SelectItem>
              </SelectContent>
            </Select>

            <Select value={selectedShipping} onValueChange={setSelectedShipping}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Shipping Option" />
              </SelectTrigger>
              <SelectContent>
                {shippingOptions.map((option) => (
                  <SelectItem key={option.id} value={option.id}>
                    {option.name} - R{option.price} ({option.time})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center space-x-2">
            <Button variant={viewMode === "grid" ? "default" : "outline"} size="sm" onClick={() => setViewMode("grid")}>
              <Grid className="h-4 w-4" />
            </Button>
            <Button variant={viewMode === "list" ? "default" : "outline"} size="sm" onClick={() => setViewMode("list")}>
              <List className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Products Grid */}
        <div
          className={`grid gap-6 ${viewMode === "grid" ? "grid-cols-1 md:grid-cols-2 lg:grid-cols-3" : "grid-cols-1"}`}
        >
          {sortedProducts.map((product) => (
            <Card key={product.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="relative">
                <img
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  className="w-full h-64 object-cover"
                />
                <div className="absolute top-4 left-4 flex flex-wrap gap-2">
                  {product.badges.map((badge) => (
                    <Badge key={badge} variant="secondary" className="bg-black text-white">
                      {badge}
                    </Badge>
                  ))}
                </div>
                <div className="absolute top-4 right-4 flex space-x-2">
                  <Button size="sm" variant="secondary" className="p-2">
                    <Heart className="h-4 w-4" />
                  </Button>
                  <Button size="sm" variant="secondary" className="p-2">
                    <Share2 className="h-4 w-4" />
                  </Button>
                </div>
                <div
                  className={`absolute bottom-4 right-4 px-2 py-1 rounded text-sm font-medium ${
                    product.stock === "In Stock"
                      ? "bg-green-100 text-green-800"
                      : product.stock === "Low Stock"
                        ? "bg-yellow-100 text-yellow-800"
                        : "bg-red-100 text-red-800"
                  }`}
                >
                  {product.stock}
                </div>
              </div>

              <CardContent className="p-6">
                <div className="mb-4">
                  <h3 className="text-xl font-semibold text-black mb-2">{product.name}</h3>
                  <p className="text-gray-600 text-sm mb-3">{product.description}</p>

                  <div className="flex items-center mb-3">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`h-4 w-4 ${
                            i < Math.floor(product.rating) ? "text-yellow-400 fill-current" : "text-gray-300"
                          }`}
                        />
                      ))}
                    </div>
                    <span className="ml-2 text-sm text-gray-600">
                      {product.rating} ({product.reviews} reviews)
                    </span>
                  </div>

                  <div className="flex items-center space-x-2 mb-4">
                    <span className="text-2xl font-bold text-black">R{product.price}</span>
                    {product.originalPrice > product.price && (
                      <>
                        <span className="text-lg text-gray-500 line-through">R{product.originalPrice}</span>
                        <Badge variant="destructive">Save R{product.originalPrice - product.price}</Badge>
                      </>
                    )}
                  </div>

                  <div className="mb-4">
                    <h4 className="font-semibold mb-2">Key Features:</h4>
                    <div className="flex flex-wrap gap-2">
                      {product.features.map((feature) => (
                        <Badge key={feature} variant="outline" className="text-xs">
                          {feature}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  {viewMode === "list" && (
                    <div className="mb-4">
                      <h4 className="font-semibold mb-2">Specifications:</h4>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        {Object.entries(product.specifications).map(([key, value]) => (
                          <div key={key}>
                            <span className="text-gray-600">{key}:</span>
                            <span className="ml-1 font-medium">{value}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <div className="space-y-3">
                  <div className="text-sm text-gray-600">
                    <strong>Shipping:</strong> {shippingOptions.find((s) => s.id === selectedShipping)?.name}
                    (+R{shippingOptions.find((s) => s.id === selectedShipping)?.price})
                  </div>

                  <Button
                    onClick={() => handleAddToCart(product)}
                    className="w-full bg-black text-white hover:bg-gray-800"
                    disabled={product.stock === "Out of Stock"}
                  >
                    <ShoppingCart className="mr-2 h-4 w-4" />
                    Add to Cart - R
                    {product.price + (shippingOptions.find((s) => s.id === selectedShipping)?.price || 0)}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Free Shipping Notice */}
        <div className="mt-12 p-6 bg-green-50 border border-green-200 rounded-lg">
          <h3 className="text-lg font-semibold text-green-800 mb-2">Free Shipping Available!</h3>
          <p className="text-green-700">
            Get free standard shipping on orders over R500. Premium items qualify for free express shipping on orders
            over R1000.
          </p>
        </div>
      </div>
    </div>
  )
}
