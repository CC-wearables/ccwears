"use client"

import { useState } from "react"
import Link from "next/link"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useCart } from "@/components/cart-provider"
import { useToast } from "@/hooks/use-toast"

import { List, Grid, Filter, Palette, ShoppingCart, Sparkle, Star } from "lucide-react"

/* -------------------------------------------------------------------------- */
/*                              MOCKED PRODUCTS                               */
/* -------------------------------------------------------------------------- */

type ShippingTier = "standard" | "express" | "overnight"

interface Product {
  id: string
  name: string
  description: string
  price: number
  originalPrice?: number
  image: string
  rating: number
  reviews: number
  productionTime: string
  sizes: string[]
  colors: string[]
  printAreas: string[]
  shipping: Record<
    ShippingTier,
    {
      price: number
      days: string
    }
  >
  badge?: string
}

const products: Product[] = [
  {
    id: "pod_001",
    name: "Custom T-Shirt Design",
    description: "Premium cotton tee with your own artwork.",
    price: 299,
    originalPrice: 399,
    image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400&h=400&fit=crop",
    rating: 4.8,
    reviews: 1456,
    productionTime: "3-5 business days",
    sizes: ["XS", "S", "M", "L", "XL", "XXL"],
    colors: ["White", "Black", "Navy", "Grey", "Red"],
    printAreas: ["Front", "Back", "Left Sleeve"],
    shipping: {
      standard: { price: 50, days: "3-5 business days" },
      express: { price: 100, days: "1-2 business days" },
      overnight: { price: 200, days: "Next day" },
    },
    badge: "Customizable",
  },
  {
    id: "pod_002",
    name: "Custom Hoodie Design",
    description: "Personalised fleece hoodie with adjustable hood.",
    price: 699,
    originalPrice: 899,
    image: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=400&h=400&fit=crop",
    rating: 4.7,
    reviews: 892,
    productionTime: "5-7 business days",
    sizes: ["XS", "S", "M", "L", "XL", "XXL"],
    colors: ["Black", "White", "Navy", "Grey"],
    printAreas: ["Front", "Back", "Sleeves"],
    shipping: {
      standard: { price: 50, days: "3-5 business days" },
      express: { price: 100, days: "1-2 business days" },
      overnight: { price: 200, days: "Next day" },
    },
    badge: "Popular",
  },
  // --- add more products as needed ---
]

/* -------------------------------------------------------------------------- */

export default function PrintOnDemandPage() {
  const [view, setView] = useState<"grid" | "list">("grid")
  const [sortBy, setSortBy] = useState("featured")

  const [selectedSize, setSelectedSize] = useState<Record<string, string>>({})
  const [selectedColor, setSelectedColor] = useState<Record<string, string>>({})
  const [selectedShipping, setSelectedShipping] = useState<Record<string, ShippingTier>>({})

  const { addItem } = useCart()
  const { toast } = useToast()

  /* --------------------------- derived + handlers ------------------------- */

  const sortedProducts = [...products].sort((a, b) => {
    switch (sortBy) {
      case "price-low":
        return a.price - b.price
      case "price-high":
        return b.price - a.price
      case "rating":
        return b.rating - a.rating
      default:
        return 0
    }
  })

  const handleAddToCart = (product: Product) => {
    const shipTier = selectedShipping[product.id] ?? "standard"
    const size = selectedSize[product.id] ?? product.sizes[0]
    const color = selectedColor[product.id] ?? product.colors[0]
    const shippingCost = product.shipping[shipTier].price

    addItem({
      id: product.id,
      name: `${product.name} (${size}, ${color})`,
      price: product.price + shippingCost,
      image: product.image,
      category: "print-on-demand",
    })

    toast({
      title: "Added to cart!",
      description: `${product.name} with ${shipTier} shipping has been added.`,
    })
  }

  /* -------------------------------- render -------------------------------- */

  return (
    <main className="min-h-screen bg-white">
      <section className="container mx-auto px-4 py-10">
        <header className="mb-8 space-y-2">
          <h1 className="text-4xl font-bold">Print on Demand</h1>
          <p className="text-gray-600">Personalise apparel, accessories and more with our easy design tools.</p>
        </header>

        {/* Controls */}
        <div className="flex flex-col md:flex-row justify-between gap-4 mb-8">
          <div className="flex items-center gap-4">
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-44">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="featured">Featured</SelectItem>
                <SelectItem value="price-low">Price – low to high</SelectItem>
                <SelectItem value="price-high">Price – high to low</SelectItem>
                <SelectItem value="rating">Highest rated</SelectItem>
              </SelectContent>
            </Select>

            <Button size="sm" variant="outline">
              <Filter className="mr-2 h-4 w-4" />
              Filters
            </Button>
          </div>

          <div className="flex gap-2">
            <Button size="sm" variant={view === "grid" ? "default" : "outline"} onClick={() => setView("grid")}>
              <Grid className="h-4 w-4" />
            </Button>
            <Button size="sm" variant={view === "list" ? "default" : "outline"} onClick={() => setView("list")}>
              <List className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Products */}
        <div className={view === "grid" ? "grid gap-8 md:grid-cols-2 lg:grid-cols-3" : "space-y-8"}>
          {sortedProducts.map((product) => (
            <Card key={product.id} className="border-2 hover:border-purple-500">
              <CardHeader className="p-0">
                <Link href={`/product/${product.id}`}>
                  <img
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    className="h-64 w-full rounded-t-lg object-cover"
                  />
                </Link>

                {product.badge && (
                  <Badge className="absolute top-4 left-4 bg-purple-600 text-white">{product.badge}</Badge>
                )}
                <Badge className="absolute top-4 right-4 bg-black text-white">
                  <Sparkle className="mr-1 h-3 w-3" />
                  Custom
                </Badge>
              </CardHeader>

              <CardContent className="space-y-4 p-6">
                <div>
                  <Link href={`/product/${product.id}`}>
                    <CardTitle className="mb-1 hover:text-gray-700">{product.name}</CardTitle>
                  </Link>
                  <p className="text-sm text-gray-600">{product.description}</p>
                </div>

                {/* Rating */}
                <div className="flex items-center gap-2">
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`h-4 w-4 ${
                          i < Math.floor(product.rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-xs text-gray-500">
                    {product.rating} ({product.reviews})
                  </span>
                </div>

                {/* Price */}
                <div className="flex items-center gap-2">
                  <span className="text-2xl font-bold">R{product.price}</span>
                  {product.originalPrice && (
                    <span className="text-sm line-through text-gray-500">R{product.originalPrice}</span>
                  )}
                </div>

                {/* Size */}
                <div>
                  <label className="mb-1 block text-xs font-medium">Size / Model</label>
                  <Select
                    value={selectedSize[product.id] ?? product.sizes[0]}
                    onValueChange={(v) => setSelectedSize((p) => ({ ...p, [product.id]: v }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {product.sizes.map((s) => (
                        <SelectItem key={s} value={s}>
                          {s}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Color */}
                <div>
                  <label className="mb-1 block text-xs font-medium">Base colour</label>
                  <Select
                    value={selectedColor[product.id] ?? product.colors[0]}
                    onValueChange={(v) => setSelectedColor((p) => ({ ...p, [product.id]: v }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {product.colors.map((c) => (
                        <SelectItem key={c} value={c}>
                          {c}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Shipping */}
                <div>
                  <label className="mb-1 block text-xs font-medium">Shipping</label>
                  <Select
                    value={selectedShipping[product.id] ?? "standard"}
                    onValueChange={(v: ShippingTier) => setSelectedShipping((p) => ({ ...p, [product.id]: v }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {(Object.keys(product.shipping) as ShippingTier[]).map((tier) => (
                        <SelectItem key={tier} value={tier}>
                          {tier.charAt(0).toUpperCase() + tier.slice(1)} – R{product.shipping[tier].price} (
                          {product.shipping[tier].days})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Actions */}
                <div className="space-y-2">
                  <Button className="w-full bg-purple-600 text-white hover:bg-purple-700">
                    <Palette className="mr-2 h-4 w-4" />
                    Customise design
                  </Button>

                  <Button variant="outline" className="w-full bg-transparent" onClick={() => handleAddToCart(product)}>
                    <ShoppingCart className="mr-2 h-4 w-4" />
                    Add to cart
                  </Button>

                  <Button asChild variant="ghost" className="w-full">
                    <Link href={`/product/${product.id}`}>View details</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    </main>
  )
}
