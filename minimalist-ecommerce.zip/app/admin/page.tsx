"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"
import {
  Plus,
  TrendingUp,
  DollarSign,
  ShoppingCart,
  Edit,
  Trash2,
  ExternalLink,
  CreditCard,
  Bot,
  Zap,
  Globe,
  Target,
  Mail,
  Settings,
  Palette,
  Type,
  Link,
  Save,
} from "lucide-react"
import { Switch } from "@/components/ui/switch"
import { ImageUpload } from "@/components/image-upload"
import {
  getAISystem,
  startAutomation,
  type AIAgent,
  type SocialMediaConfig,
  type PriceMonitorConfig,
} from "@/lib/ai-automation"

interface EmailConfig {
  purpose: string
  email: string
  description: string
  enabled: boolean
}

interface SiteContent {
  section: string
  element: string
  content: string
  type: "text" | "image" | "link" | "color"
}

export default function AdminPage() {
  const [activeTab, setActiveTab] = useState("dashboard")
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const { toast } = useToast()
  const router = useRouter()

  const [businessSettings, setBusinessSettings] = useState({
    businessAccount: "",
    notificationEmail: "",
    highValueThreshold: 5000,
    autoFulfillment: true,
    profitMargin: 16.67,
  })

  const [newProduct, setNewProduct] = useState({
    name: "",
    supplierPrice: "",
    sellingPrice: "",
    category: "",
    description: "",
    image: "",
    supplierUrl: "",
    stock: "",
    autoOrder: true,
  })

  const [importSettings, setImportSettings] = useState({
    supplierApi: "",
    apiKey: "",
    autoSync: false,
    syncInterval: "24",
  })

  const [products, setProducts] = useState([])
  const [aiSystem] = useState(() => getAISystem())
  const [aiConfig, setAiConfig] = useState(aiSystem.getConfig())

  const [aiIntegrations, setAiIntegrations] = useState(aiSystem.getConfig().aiIntegrations || [])
  const [premiumFeatures, setPremiumFeatures] = useState(aiSystem.getConfig().premiumFeatures || {})

  // Email Management State
  const [emailConfigs, setEmailConfigs] = useState<EmailConfig[]>([
    {
      purpose: "Admin Issues",
      email: "admin@ccwearables.com",
      description: "Administrative notifications, system alerts, and internal communications",
      enabled: true,
    },
    {
      purpose: "Product Updates",
      email: "products@ccwearables.com",
      description: "New product launches, trending items, and inventory notifications",
      enabled: true,
    },
    {
      purpose: "Customer Support",
      email: "support@ccwearables.com",
      description: "Customer service inquiries, support tickets, and consultant communications",
      enabled: true,
    },
    {
      purpose: "Marketing Campaigns",
      email: "marketing@ccwearables.com",
      description: "Promotional emails, newsletters, and marketing automation",
      enabled: true,
    },
    {
      purpose: "Order Processing",
      email: "orders@ccwearables.com",
      description: "Order confirmations, shipping updates, and fulfillment notifications",
      enabled: true,
    },
    {
      purpose: "General Inquiries",
      email: "hello@ccwearables.com",
      description: "General customer inquiries and business communications",
      enabled: true,
    },
  ])

  // Site Editing State
  const [siteContent, setSiteContent] = useState<SiteContent[]>([
    {
      section: "Header",
      element: "Logo Text",
      content: "CC Wearables",
      type: "text",
    },
    {
      section: "Header",
      element: "Tagline",
      content: "Premium Tech & Fashion",
      type: "text",
    },
    {
      section: "Hero",
      element: "Main Heading",
      content: "Discover Premium Wearable Technology & Fashion",
      type: "text",
    },
    {
      section: "Hero",
      element: "Subheading",
      content: "Where cutting-edge technology meets contemporary style",
      type: "text",
    },
    {
      section: "Hero",
      element: "CTA Button",
      content: "Shop Now",
      type: "text",
    },
    {
      section: "Categories",
      element: "Electronics Title",
      content: "Smart Electronics",
      type: "text",
    },
    {
      section: "Categories",
      element: "Clothing Title",
      content: "Premium Clothing",
      type: "text",
    },
    {
      section: "Categories",
      element: "Print Title",
      content: "Custom Print-on-Demand",
      type: "text",
    },
    {
      section: "Footer",
      element: "Company Description",
      content: "Your premier destination for wearable technology and fashion",
      type: "text",
    },
    {
      section: "Colors",
      element: "Primary Color",
      content: "#000000",
      type: "color",
    },
    {
      section: "Colors",
      element: "Secondary Color",
      content: "#6B7280",
      type: "color",
    },
  ])

  const [editingContent, setEditingContent] = useState<SiteContent | null>(null)

  useEffect(() => {
    const savedProducts = JSON.parse(localStorage.getItem("admin_products") || "[]")
    setProducts(savedProducts)

    // Load saved email configs
    const savedEmailConfigs = localStorage.getItem("email_configs")
    if (savedEmailConfigs) {
      setEmailConfigs(JSON.parse(savedEmailConfigs))
    }

    // Load saved site content
    const savedSiteContent = localStorage.getItem("site_content")
    if (savedSiteContent) {
      setSiteContent(JSON.parse(savedSiteContent))
    }

    // Start AI automation
    startAutomation()
  }, [])

  useEffect(() => {
    const adminAuth = localStorage.getItem("adminAuth")
    if (adminAuth !== "true") {
      router.push("/admin/login")
    } else {
      setIsAuthenticated(true)
    }
  }, [router])

  const handleAddProduct = (e: React.FormEvent) => {
    e.preventDefault()
    const profit = Number.parseFloat(newProduct.sellingPrice) - Number.parseFloat(newProduct.supplierPrice)
    const margin = (profit / Number.parseFloat(newProduct.sellingPrice)) * 100

    const productToAdd = {
      id: `prod_${Date.now()}`,
      name: newProduct.name,
      price: Number.parseFloat(newProduct.sellingPrice),
      category: newProduct.category,
      description: newProduct.description,
      image: newProduct.image,
      stock: Number.parseInt(newProduct.stock) || 999,
      supplierCost: Number.parseFloat(newProduct.supplierPrice),
      supplierUrl: newProduct.supplierUrl,
      autoFulfill: newProduct.autoOrder,
      isActive: true,
      createdAt: new Date().toISOString(),
    }

    const existingProducts = JSON.parse(localStorage.getItem("admin_products") || "[]")
    const updatedProducts = [...existingProducts, productToAdd]
    localStorage.setItem("admin_products", JSON.stringify(updatedProducts))
    setProducts(updatedProducts)

    toast({
      title: "Product Added Successfully",
      description: `${newProduct.name} added with R${profit.toFixed(2)} profit (${margin.toFixed(1)}% margin). Now available in catalog!`,
    })

    setNewProduct({
      name: "",
      supplierPrice: "",
      sellingPrice: "",
      category: "",
      description: "",
      image: "",
      supplierUrl: "",
      stock: "",
      autoOrder: true,
    })
  }

  const updateSocialMediaConfig = (platform: string, config: Partial<SocialMediaConfig>) => {
    const newConfig = {
      ...aiConfig,
      socialMedia: aiConfig.socialMedia.map((sm) => (sm.platform === platform ? { ...sm, ...config } : sm)),
    }
    setAiConfig(newConfig)
    aiSystem.updateConfig(newConfig)

    toast({
      title: "Social Media Settings Updated",
      description: `${platform} configuration has been saved`,
    })
  }

  const updateAIAgent = (agentId: string, updates: Partial<AIAgent>) => {
    const newConfig = {
      ...aiConfig,
      aiAgents: aiConfig.aiAgents.map((agent) => (agent.id === agentId ? { ...agent, ...updates } : agent)),
    }
    setAiConfig(newConfig)
    aiSystem.updateConfig(newConfig)

    toast({
      title: "AI Agent Updated",
      description: `${updates.name || agentId} configuration has been saved`,
    })
  }

  const updatePriceMonitoring = (retailer: string, config: Partial<PriceMonitorConfig>) => {
    const newConfig = {
      ...aiConfig,
      priceMonitoring: aiConfig.priceMonitoring.map((pm) => (pm.retailer === retailer ? { ...pm, ...config } : pm)),
    }
    setAiConfig(newConfig)
    aiSystem.updateConfig(newConfig)

    toast({
      title: "Price Monitoring Updated",
      description: `${retailer} monitoring configuration has been saved`,
    })
  }

  const updateAIIntegration = (integrationId: string, updates: any) => {
    const newIntegrations = aiIntegrations.map((ai) => (ai.id === integrationId ? { ...ai, ...updates } : ai))
    setAiIntegrations(newIntegrations)

    const newConfig = { ...aiConfig, aiIntegrations: newIntegrations }
    setAiConfig(newConfig)
    aiSystem.updateConfig(newConfig)

    toast({
      title: "AI Integration Updated",
      description: `${updates.name || integrationId} configuration has been saved`,
    })
  }

  const toggleAIPermission = (integrationId: string, permissionIndex: number) => {
    const newIntegrations = aiIntegrations.map((ai) => {
      if (ai.id === integrationId) {
        const newPermissions = [...ai.permissions]
        newPermissions[permissionIndex].enabled = !newPermissions[permissionIndex].enabled
        return { ...ai, permissions: newPermissions }
      }
      return ai
    })
    setAiIntegrations(newIntegrations)

    const newConfig = { ...aiConfig, aiIntegrations: newIntegrations }
    aiSystem.updateConfig(newConfig)
  }

  const upgradePremium = (tier: "professional" | "enterprise") => {
    aiSystem.upgradeToPremium(tier)
    setPremiumFeatures(aiSystem.getConfig().premiumFeatures)

    toast({
      title: "Premium AI Activated!",
      description: `Upgraded to ${tier} tier with enhanced AI capabilities`,
    })
  }

  const testAIIntegration = async (integrationId: string) => {
    try {
      const result = await aiSystem.executeAITask(integrationId, "generate-description", {
        productName: "Test Product",
        category: "electronics",
      })

      toast({
        title: "AI Test Successful",
        description: "AI integration is working correctly",
      })
    } catch (error) {
      toast({
        title: "AI Test Failed",
        description: error.message,
        variant: "destructive",
      })
    }
  }

  // Email Management Functions
  const updateEmailConfig = (index: number, updates: Partial<EmailConfig>) => {
    const newConfigs = emailConfigs.map((config, i) => (i === index ? { ...config, ...updates } : config))
    setEmailConfigs(newConfigs)
    localStorage.setItem("email_configs", JSON.stringify(newConfigs))

    toast({
      title: "Email Configuration Updated",
      description: "Email settings have been saved successfully",
    })
  }

  const addEmailConfig = () => {
    const newConfig: EmailConfig = {
      purpose: "New Purpose",
      email: "new@ccwearables.com",
      description: "Description for new email purpose",
      enabled: true,
    }
    const newConfigs = [...emailConfigs, newConfig]
    setEmailConfigs(newConfigs)
    localStorage.setItem("email_configs", JSON.stringify(newConfigs))
  }

  // Site Editing Functions
  const updateSiteContent = (index: number, newContent: string) => {
    const newSiteContent = siteContent.map((item, i) => (i === index ? { ...item, content: newContent } : item))
    setSiteContent(newSiteContent)
    localStorage.setItem("site_content", JSON.stringify(newSiteContent))

    toast({
      title: "Site Content Updated",
      description: `${siteContent[index].element} has been updated`,
    })
  }

  const addSiteContentItem = () => {
    const newItem: SiteContent = {
      section: "Custom",
      element: "New Element",
      content: "New Content",
      type: "text",
    }
    const newSiteContent = [...siteContent, newItem]
    setSiteContent(newSiteContent)
    localStorage.setItem("site_content", JSON.stringify(newSiteContent))
  }

  const stats = [
    { title: "Total Revenue", value: "R125,678", icon: DollarSign, change: "+23%" },
    { title: "Profit Margin", value: `${businessSettings.profitMargin}%`, icon: TrendingUp, change: "+2%" },
    { title: "Auto Orders", value: "45", icon: ShoppingCart, change: "+12%" },
    {
      title: "AI Agents Active",
      value: aiConfig.aiAgents.filter((a) => a.enabled).length.toString(),
      icon: Bot,
      change: "+100%",
    },
  ]

  if (!isAuthenticated) {
    return <div>Loading...</div>
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <img src="/cc-wearables-logo.jpg" alt="CC Wearables" className="h-12 w-auto" />
            <div>
              <h1 className="text-4xl font-bold text-black">CC Wearables Admin</h1>
              <p className="text-gray-600">AI-Powered E-commerce Management</p>
            </div>
          </div>
          <Button
            onClick={() => {
              localStorage.removeItem("adminAuth")
              router.push("/admin/login")
            }}
            variant="outline"
          >
            Logout
          </Button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex flex-wrap space-x-1 mb-8 bg-white p-1 rounded-lg border-2 border-gray-200">
          {[
            { id: "dashboard", label: "Dashboard" },
            { id: "products", label: "Products" },
            { id: "ai-automation", label: "AI Automation" },
            { id: "social-media", label: "Social Media" },
            { id: "price-monitoring", label: "Price Monitoring" },
            { id: "marketing", label: "Marketing & SEO" },
            { id: "ai-integrations", label: "AI Integrations" },
            { id: "email-management", label: "Email Management" },
            { id: "site-editing", label: "Site Editing" },
            { id: "business", label: "Business Settings" },
          ].map((tab) => (
            <Button
              key={tab.id}
              variant={activeTab === tab.id ? "default" : "ghost"}
              onClick={() => setActiveTab(tab.id)}
              className={activeTab === tab.id ? "bg-black text-white" : ""}
              size="sm"
            >
              {tab.label}
            </Button>
          ))}
        </div>

        {/* Dashboard Tab */}
        {activeTab === "dashboard" && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {stats.map((stat) => (
                <Card key={stat.title} className="border-2 border-gray-200">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">{stat.title}</p>
                        <p className="text-2xl font-bold text-black">{stat.value}</p>
                        <p className="text-sm text-green-600">{stat.change}</p>
                      </div>
                      <stat.icon className="h-8 w-8 text-gray-400" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* AI Status Dashboard */}
            <Card className="border-2 border-blue-500">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Bot className="mr-2 h-5 w-5" />
                  AI Automation Status
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {aiConfig.aiAgents.map((agent) => (
                    <div key={agent.id} className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium">{agent.name}</h4>
                        <div className={`w-3 h-3 rounded-full ${agent.enabled ? "bg-green-500" : "bg-red-500"}`}></div>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">{agent.type}</p>
                      <div className="text-xs text-gray-500">Status: {agent.status}</div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Email Management Tab */}
        {activeTab === "email-management" && (
          <div className="space-y-8">
            <Card className="border-2 border-blue-500">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Mail className="mr-2 h-5 w-5" />
                  Email Configuration Management
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {emailConfigs.map((config, index) => (
                    <Card key={index} className="border">
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-lg">{config.purpose}</CardTitle>
                          <Switch
                            checked={config.enabled}
                            onCheckedChange={(enabled) => updateEmailConfig(index, { enabled })}
                          />
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div>
                            <Label>Email Address</Label>
                            <Input
                              value={config.email}
                              onChange={(e) => updateEmailConfig(index, { email: e.target.value })}
                              placeholder="email@ccwearables.com"
                            />
                          </div>
                          <div>
                            <Label>Purpose</Label>
                            <Input
                              value={config.purpose}
                              onChange={(e) => updateEmailConfig(index, { purpose: e.target.value })}
                              placeholder="Email purpose"
                            />
                          </div>
                          <div>
                            <Label>Description</Label>
                            <Textarea
                              value={config.description}
                              onChange={(e) => updateEmailConfig(index, { description: e.target.value })}
                              placeholder="Describe what this email is used for"
                              rows={2}
                            />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                  <Button onClick={addEmailConfig} className="w-full bg-transparent" variant="outline">
                    <Plus className="mr-2 h-4 w-4" />
                    Add New Email Configuration
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Site Editing Tab */}
        {activeTab === "site-editing" && (
          <div className="space-y-8">
            <Card className="border-2 border-purple-500">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Edit className="mr-2 h-5 w-5" />
                  Website Content Editor
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {/* Group content by section */}
                  {["Header", "Hero", "Categories", "Footer", "Colors"].map((section) => (
                    <Card key={section} className="border">
                      <CardHeader>
                        <CardTitle className="text-lg flex items-center">
                          {section === "Header" && <Type className="mr-2 h-4 w-4" />}
                          {section === "Hero" && <Zap className="mr-2 h-4 w-4" />}
                          {section === "Categories" && <Settings className="mr-2 h-4 w-4" />}
                          {section === "Footer" && <Link className="mr-2 h-4 w-4" />}
                          {section === "Colors" && <Palette className="mr-2 h-4 w-4" />}
                          {section} Section
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          {siteContent
                            .filter((item) => item.section === section)
                            .map((item, index) => {
                              const globalIndex = siteContent.findIndex((content) => content === item)
                              return (
                                <div
                                  key={globalIndex}
                                  className="grid md:grid-cols-3 gap-4 items-center p-4 border rounded"
                                >
                                  <div>
                                    <Label className="font-medium">{item.element}</Label>
                                    <p className="text-sm text-gray-600">{item.type}</p>
                                  </div>
                                  <div className="md:col-span-2">
                                    {item.type === "text" && (
                                      <Input
                                        value={item.content}
                                        onChange={(e) => updateSiteContent(globalIndex, e.target.value)}
                                        placeholder="Enter text content"
                                      />
                                    )}
                                    {item.type === "color" && (
                                      <div className="flex items-center space-x-2">
                                        <input
                                          type="color"
                                          value={item.content}
                                          onChange={(e) => updateSiteContent(globalIndex, e.target.value)}
                                          className="w-12 h-10 border rounded"
                                        />
                                        <Input
                                          value={item.content}
                                          onChange={(e) => updateSiteContent(globalIndex, e.target.value)}
                                          placeholder="#000000"
                                          className="flex-1"
                                        />
                                      </div>
                                    )}
                                    {item.type === "image" && (
                                      <div className="space-y-2">
                                        <Input
                                          value={item.content}
                                          onChange={(e) => updateSiteContent(globalIndex, e.target.value)}
                                          placeholder="Image URL"
                                        />
                                        {item.content && (
                                          <img
                                            src={item.content || "/placeholder.svg"}
                                            alt="Preview"
                                            className="w-20 h-20 object-cover rounded"
                                          />
                                        )}
                                      </div>
                                    )}
                                    {item.type === "link" && (
                                      <Input
                                        value={item.content}
                                        onChange={(e) => updateSiteContent(globalIndex, e.target.value)}
                                        placeholder="https://example.com"
                                      />
                                    )}
                                  </div>
                                </div>
                              )
                            })}
                        </div>
                      </CardContent>
                    </Card>
                  ))}

                  {/* Add New Content Item */}
                  <Card className="border-dashed border-2">
                    <CardContent className="p-6">
                      <Button onClick={addSiteContentItem} className="w-full bg-transparent" variant="outline">
                        <Plus className="mr-2 h-4 w-4" />
                        Add New Content Element
                      </Button>
                    </CardContent>
                  </Card>

                  {/* Quick Actions */}
                  <Card className="border-2 border-green-500">
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <Save className="mr-2 h-5 w-5" />
                        Quick Actions
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid md:grid-cols-2 gap-4">
                        <Button
                          onClick={() => {
                            // Export site content
                            const dataStr = JSON.stringify(siteContent, null, 2)
                            const dataBlob = new Blob([dataStr], { type: "application/json" })
                            const url = URL.createObjectURL(dataBlob)
                            const link = document.createElement("a")
                            link.href = url
                            link.download = "site-content-backup.json"
                            link.click()
                          }}
                          variant="outline"
                        >
                          Export Content Backup
                        </Button>
                        <Button
                          onClick={() => {
                            toast({
                              title: "Changes Applied",
                              description: "All site content changes have been saved and applied",
                            })
                          }}
                          className="bg-green-600 text-white hover:bg-green-700"
                        >
                          Apply All Changes
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* AI Automation Tab */}
        {activeTab === "ai-automation" && (
          <div className="space-y-8">
            <Card className="border-2 border-purple-500">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Bot className="mr-2 h-5 w-5" />
                  AI Agents Configuration
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {aiConfig.aiAgents.map((agent) => (
                    <Card key={agent.id} className="border">
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-lg">{agent.name}</CardTitle>
                          <Switch
                            checked={agent.enabled}
                            onCheckedChange={(enabled) => updateAIAgent(agent.id, { enabled })}
                          />
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="grid md:grid-cols-2 gap-4">
                          <div>
                            <Label>Agent Type</Label>
                            <p className="text-sm text-gray-600 capitalize">{agent.type.replace("-", " ")}</p>
                          </div>
                          <div>
                            <Label>Status</Label>
                            <div className="flex items-center space-x-2">
                              <div
                                className={`w-2 h-2 rounded-full ${agent.status === "active" ? "bg-green-500" : "bg-red-500"}`}
                              ></div>
                              <span className="text-sm capitalize">{agent.status}</span>
                            </div>
                          </div>
                          <div className="md:col-span-2">
                            <Label>Permissions</Label>
                            <div className="flex flex-wrap gap-2 mt-1">
                              {agent.permissions.map((permission) => (
                                <span key={permission} className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">
                                  {permission}
                                </span>
                              ))}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Social Media Tab */}
        {activeTab === "social-media" && (
          <div className="space-y-8">
            <Card className="border-2 border-blue-500">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Globe className="mr-2 h-5 w-5" />
                  Social Media Integration
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {aiConfig.socialMedia.map((platform) => (
                    <Card key={platform.platform} className="border">
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-lg capitalize">{platform.platform}</CardTitle>
                          <Switch
                            checked={platform.enabled}
                            onCheckedChange={(enabled) => updateSocialMediaConfig(platform.platform, { enabled })}
                          />
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div>
                            <Label htmlFor={`${platform.platform}-url`}>Profile URL</Label>
                            <Input
                              id={`${platform.platform}-url`}
                              value={platform.profileUrl}
                              onChange={(e) =>
                                updateSocialMediaConfig(platform.platform, { profileUrl: e.target.value })
                              }
                              placeholder={`https://${platform.platform}.com/ccwearables`}
                            />
                          </div>
                          <div>
                            <Label htmlFor={`${platform.platform}-token`}>API Token/Key</Label>
                            <Input
                              id={`${platform.platform}-token`}
                              type="password"
                              value={platform.accessToken || ""}
                              onChange={(e) =>
                                updateSocialMediaConfig(platform.platform, { accessToken: e.target.value })
                              }
                              placeholder="Enter API token for automated posting"
                            />
                          </div>
                          <div className="grid md:grid-cols-2 gap-4">
                            <div className="flex items-center space-x-2">
                              <Switch
                                checked={platform.autoPost}
                                onCheckedChange={(autoPost) => updateSocialMediaConfig(platform.platform, { autoPost })}
                              />
                              <Label>Enable Auto-Posting</Label>
                            </div>
                            <div>
                              <Label>Post Frequency</Label>
                              <Select
                                value={platform.postFrequency}
                                onValueChange={(postFrequency) =>
                                  updateSocialMediaConfig(platform.platform, { postFrequency })
                                }
                              >
                                <SelectTrigger>
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="hourly">Hourly</SelectItem>
                                  <SelectItem value="daily">Daily</SelectItem>
                                  <SelectItem value="weekly">Weekly</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Price Monitoring Tab */}
        {activeTab === "price-monitoring" && (
          <div className="space-y-8">
            <Card className="border-2 border-green-500">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Target className="mr-2 h-5 w-5" />
                  Automated Price Monitoring
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {aiConfig.priceMonitoring.map((monitor) => (
                    <Card key={monitor.retailer} className="border">
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-lg capitalize">{monitor.retailer}</CardTitle>
                          <Switch
                            checked={monitor.enabled}
                            onCheckedChange={(enabled) => updatePriceMonitoring(monitor.retailer, { enabled })}
                          />
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="grid md:grid-cols-2 gap-4">
                          <div>
                            <Label>Update Frequency</Label>
                            <Select
                              value={monitor.updateFrequency}
                              onValueChange={(updateFrequency) =>
                                updatePriceMonitoring(monitor.retailer, { updateFrequency })
                              }
                            >
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="hourly">Hourly</SelectItem>
                                <SelectItem value="daily">Daily</SelectItem>
                                <SelectItem value="weekly">Weekly</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <Label>Profit Margin Type</Label>
                            <Select
                              value={monitor.profitMarginType}
                              onValueChange={(profitMarginType) =>
                                updatePriceMonitoring(monitor.retailer, { profitMarginType })
                              }
                            >
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="fixed">Fixed Amount (ZAR)</SelectItem>
                                <SelectItem value="percentage">Percentage (%)</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <Label>Profit Value</Label>
                            <Input
                              type="number"
                              value={monitor.profitValue}
                              onChange={(e) =>
                                updatePriceMonitoring(monitor.retailer, {
                                  profitValue: Number.parseFloat(e.target.value),
                                })
                              }
                              placeholder={monitor.profitMarginType === "fixed" ? "Amount in ZAR" : "Percentage"}
                            />
                          </div>
                          <div>
                            <Label>Scrape URL</Label>
                            <Input
                              value={monitor.scrapeUrl || ""}
                              onChange={(e) => updatePriceMonitoring(monitor.retailer, { scrapeUrl: e.target.value })}
                              placeholder="https://retailer.com"
                            />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Marketing & SEO Tab */}
        {activeTab === "marketing" && (
          <div className="space-y-8">
            <Card className="border-2 border-orange-500">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Zap className="mr-2 h-5 w-5" />
                  Automated Marketing & SEO
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <Label>Target Regions (South Africa)</Label>
                    <div className="grid md:grid-cols-3 gap-2 mt-2">
                      {["Johannesburg", "Cape Town", "Durban", "Pretoria", "Port Elizabeth", "Bloemfontein"].map(
                        (city) => (
                          <div key={city} className="flex items-center space-x-2">
                            <Switch defaultChecked />
                            <Label>{city}</Label>
                          </div>
                        ),
                      )}
                    </div>
                  </div>

                  <div>
                    <Label>SEO Keywords</Label>
                    <Textarea
                      placeholder="trending products south africa, online shopping sa, best deals cape town..."
                      rows={3}
                    />
                  </div>

                  <div>
                    <Label>Backlink Strategy</Label>
                    <Select defaultValue="subtle-integration">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="aggressive">Aggressive</SelectItem>
                        <SelectItem value="moderate">Moderate</SelectItem>
                        <SelectItem value="subtle-integration">Subtle Integration</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="flex items-center space-x-2">
                      <Switch defaultChecked />
                      <Label>Auto-generate SEO content</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch defaultChecked />
                      <Label>Local SA market focus</Label>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* AI Integrations Tab */}
        {activeTab === "ai-integrations" && (
          <div className="space-y-8">
            {/* Premium Features Card */}
            <Card className="border-2 border-purple-500">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Zap className="mr-2 h-5 w-5" />
                  Premium AI Features
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h3 className="font-semibold">Current Plan: {premiumFeatures.tier || "Basic"}</h3>
                        <p className="text-sm text-gray-600">
                          {premiumFeatures.creditsUsed || 0} / {premiumFeatures.monthlyCredits || 1000} credits used
                        </p>
                      </div>
                      <div
                        className={`px-3 py-1 rounded-full text-sm ${
                          premiumFeatures.enabled ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"
                        }`}
                      >
                        {premiumFeatures.enabled ? "Premium" : "Basic"}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Advanced Analytics</span>
                        <div
                          className={`w-3 h-3 rounded-full ${
                            premiumFeatures.features?.advancedAnalytics ? "bg-green-500" : "bg-gray-300"
                          }`}
                        ></div>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Real-time Monitoring</span>
                        <div
                          className={`w-3 h-3 rounded-full ${
                            premiumFeatures.features?.realTimeMonitoring ? "bg-green-500" : "bg-gray-300"
                          }`}
                        ></div>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Custom Models</span>
                        <div
                          className={`w-3 h-3 rounded-full ${
                            premiumFeatures.features?.customModels ? "bg-green-500" : "bg-gray-300"
                          }`}
                        ></div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <Button
                      onClick={() => upgradePremium("professional")}
                      className="w-full"
                      variant={premiumFeatures.tier === "professional" ? "secondary" : "default"}
                    >
                      {premiumFeatures.tier === "professional" ? "Current Plan" : "Upgrade to Professional"}
                      <span className="ml-2 text-sm">R299/month</span>
                    </Button>
                    <Button
                      onClick={() => upgradePremium("enterprise")}
                      className="w-full"
                      variant={premiumFeatures.tier === "enterprise" ? "secondary" : "outline"}
                    >
                      {premiumFeatures.tier === "enterprise" ? "Current Plan" : "Upgrade to Enterprise"}
                      <span className="ml-2 text-sm">R999/month</span>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* AI Integrations Management */}
            <Card className="border-2 border-blue-500">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Bot className="mr-2 h-5 w-5" />
                  AI Integrations & Permissions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {aiIntegrations.map((integration) => (
                    <Card key={integration.id} className="border">
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <CardTitle className="text-lg">{integration.name}</CardTitle>
                            <div
                              className={`px-2 py-1 rounded text-xs ${
                                integration.isPremium ? "bg-purple-100 text-purple-800" : "bg-blue-100 text-blue-800"
                              }`}
                            >
                              {integration.isPremium ? "Premium" : "Standard"}
                            </div>
                            <div
                              className={`w-3 h-3 rounded-full ${
                                integration.status === "active"
                                  ? "bg-green-500"
                                  : integration.status === "error"
                                    ? "bg-red-500"
                                    : "bg-gray-300"
                              }`}
                            ></div>
                          </div>
                          <Switch
                            checked={integration.enabled}
                            onCheckedChange={(enabled) => updateAIIntegration(integration.id, { enabled })}
                          />
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          {/* API Configuration */}
                          <div className="grid md:grid-cols-2 gap-4">
                            <div>
                              <Label>API Key</Label>
                              <Input
                                type="password"
                                value={integration.apiKey}
                                onChange={(e) => updateAIIntegration(integration.id, { apiKey: e.target.value })}
                                placeholder="Enter API key"
                              />
                            </div>
                            <div>
                              <Label>Model</Label>
                              <Select
                                value={integration.model}
                                onChange={(model) => updateAIIntegration(integration.id, { model })}
                              >
                                <SelectTrigger>
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  {integration.provider === "openai" && (
                                    <>
                                      <SelectItem value="gpt-4">GPT-4</SelectItem>
                                      <SelectItem value="gpt-4-turbo">GPT-4 Turbo</SelectItem>
                                      <SelectItem value="gpt-3.5-turbo">GPT-3.5 Turbo</SelectItem>
                                    </>
                                  )}
                                  {integration.provider === "xai" && (
                                    <>
                                      <SelectItem value="grok-3">Grok-3</SelectItem>
                                      <SelectItem value="grok-2">Grok-2</SelectItem>
                                    </>
                                  )}
                                  {integration.provider === "groq" && (
                                    <>
                                      <SelectItem value="llama-3-70b">Llama 3 70B</SelectItem>
                                      <SelectItem value="mixtral-8x7b">Mixtral 8x7B</SelectItem>
                                    </>
                                  )}
                                </SelectContent>
                              </Select>
                            </div>
                          </div>

                          {/* Usage Stats */}
                          <div className="grid md:grid-cols-3 gap-4 p-4 bg-gray-50 rounded">
                            <div className="text-center">
                              <p className="text-sm text-gray-600">Requests Used</p>
                              <p className="text-lg font-semibold">{integration.requestsUsed}</p>
                            </div>
                            <div className="text-center">
                              <p className="text-sm text-gray-600">Monthly Limit</p>
                              <p className="text-lg font-semibold">{integration.monthlyLimit}</p>
                            </div>
                            <div className="text-center">
                              <p className="text-sm text-gray-600">Cost/Request</p>
                              <p className="text-lg font-semibold">R{integration.costPerRequest}</p>
                            </div>
                          </div>

                          {/* Permissions Management */}
                          <div>
                            <Label className="text-base font-semibold">AI Permissions</Label>
                            <div className="grid md:grid-cols-2 gap-3 mt-2">
                              {integration.permissions.map((permission, index) => (
                                <div key={index} className="flex items-center justify-between p-3 border rounded">
                                  <div>
                                    <p className="font-medium capitalize">
                                      {permission.action} {permission.resource.replace("-", " ")}
                                    </p>
                                    <p className="text-sm text-gray-600">
                                      {permission.action === "generate" && "Create content automatically"}
                                      {permission.action === "analyze" && "Analyze data and trends"}
                                      {permission.action === "manage" && "Modify system settings"}
                                      {permission.action === "optimize" && "Improve existing content"}
                                      {permission.action === "predict" && "Forecast future trends"}
                                      {permission.action === "automate" && "Execute automated tasks"}
                                    </p>
                                  </div>
                                  <Switch
                                    checked={permission.enabled}
                                    onCheckedChange={() => toggleAIPermission(integration.id, index)}
                                  />
                                </div>
                              ))}
                            </div>
                          </div>

                          {/* Capabilities */}
                          <div>
                            <Label className="text-base font-semibold">Capabilities</Label>
                            <div className="flex flex-wrap gap-2 mt-2">
                              {integration.capabilities.map((capability) => (
                                <span
                                  key={capability}
                                  className="px-3 py-1 bg-blue-100 text-blue-800 text-sm rounded-full"
                                >
                                  {capability.replace("-", " ")}
                                </span>
                              ))}
                            </div>
                          </div>

                          {/* Test Integration */}
                          <div className="flex space-x-2">
                            <Button
                              onClick={() => testAIIntegration(integration.id)}
                              variant="outline"
                              size="sm"
                              disabled={!integration.enabled || !integration.apiKey}
                            >
                              Test Integration
                            </Button>
                            <Button
                              onClick={() => {
                                // Reset usage stats
                                updateAIIntegration(integration.id, { requestsUsed: 0, status: "inactive" })
                              }}
                              variant="outline"
                              size="sm"
                            >
                              Reset Usage
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* AI Automation Controls */}
            <Card className="border-2 border-green-500">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Zap className="mr-2 h-5 w-5" />
                  Full-Time AI Automation
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 border rounded">
                    <div>
                      <h4 className="font-semibold">Continuous AI Operations</h4>
                      <p className="text-sm text-gray-600">Run AI agents 24/7 for automated business operations</p>
                    </div>
                    <Switch
                      checked={aiConfig.aiAgents.some((agent) => agent.enabled)}
                      onCheckedChange={(enabled) => {
                        if (enabled) {
                          aiSystem.runFullTimeAutomation()
                          toast({
                            title: "AI Automation Started",
                            description: "Full-time AI operations are now active",
                          })
                        }
                      }}
                    />
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="p-4 border rounded">
                      <h4 className="font-semibold mb-2">Automation Tasks</h4>
                      <ul className="text-sm space-y-1">
                        <li>• Product description generation</li>
                        <li>• Market trend analysis</li>
                        <li>• Social media content creation</li>
                        <li>• Price optimization</li>
                        <li>• Inventory management</li>
                        <li>• Customer service automation</li>
                      </ul>
                    </div>

                    <div className="p-4 border rounded">
                      <h4 className="font-semibold mb-2">Premium Features</h4>
                      <ul className="text-sm space-y-1">
                        <li
                          className={premiumFeatures.features?.realTimeMonitoring ? "text-green-600" : "text-gray-400"}
                        >
                          • Real-time monitoring
                        </li>
                        <li
                          className={premiumFeatures.features?.advancedAnalytics ? "text-green-600" : "text-gray-400"}
                        >
                          • Advanced analytics
                        </li>
                        <li className={premiumFeatures.features?.customModels ? "text-green-600" : "text-gray-400"}>
                          • Custom AI models
                        </li>
                        <li className={premiumFeatures.features?.bulkOperations ? "text-green-600" : "text-gray-400"}>
                          • Bulk operations
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Products Tab - Keep existing product management */}
        {activeTab === "products" && (
          <div className="space-y-8">
            <Card className="border-2 border-black">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Plus className="mr-2 h-5 w-5" />
                  Add New Product (Dropshipping)
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleAddProduct} className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="productName">Product Name</Label>
                      <Input
                        id="productName"
                        value={newProduct.name}
                        onChange={(e) => setNewProduct((prev) => ({ ...prev, name: e.target.value }))}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="category">Category</Label>
                      <Select onValueChange={(value) => setNewProduct((prev) => ({ ...prev, category: value }))}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="electronics">Electronics</SelectItem>
                          <SelectItem value="clothing">Clothing</SelectItem>
                          <SelectItem value="wearables">Wearables</SelectItem>
                          <SelectItem value="accessories">Accessories</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid md:grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="supplierPrice">Supplier Cost (ZAR)</Label>
                      <Input
                        id="supplierPrice"
                        type="number"
                        step="0.01"
                        value={newProduct.supplierPrice}
                        onChange={(e) => setNewProduct((prev) => ({ ...prev, supplierPrice: e.target.value }))}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="sellingPrice">Selling Price (ZAR)</Label>
                      <Input
                        id="sellingPrice"
                        type="number"
                        step="0.01"
                        value={newProduct.sellingPrice}
                        onChange={(e) => setNewProduct((prev) => ({ ...prev, sellingPrice: e.target.value }))}
                        required
                      />
                    </div>
                    <div>
                      <Label>Profit Margin</Label>
                      <div className="p-2 bg-green-50 rounded text-center">
                        {newProduct.supplierPrice && newProduct.sellingPrice ? (
                          <span className="font-bold text-green-600">
                            R
                            {(
                              Number.parseFloat(newProduct.sellingPrice) - Number.parseFloat(newProduct.supplierPrice)
                            ).toFixed(2)}
                            (
                            {(
                              ((Number.parseFloat(newProduct.sellingPrice) -
                                Number.parseFloat(newProduct.supplierPrice)) /
                                Number.parseFloat(newProduct.sellingPrice)) *
                              100
                            ).toFixed(1)}
                            %)
                          </span>
                        ) : (
                          <span className="text-gray-500">Enter prices</span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="supplierUrl">Supplier Product URL</Label>
                    <Input
                      id="supplierUrl"
                      type="url"
                      value={newProduct.supplierUrl}
                      onChange={(e) => setNewProduct((prev) => ({ ...prev, supplierUrl: e.target.value }))}
                      placeholder="https://supplier.com/product-link"
                    />
                  </div>

                  <div>
                    <Label htmlFor="description">Description</Label>
                    <Textarea
                      id="description"
                      value={newProduct.description}
                      onChange={(e) => setNewProduct((prev) => ({ ...prev, description: e.target.value }))}
                      rows={3}
                    />
                  </div>

                  <div>
                    <Label htmlFor="image">Product Image</Label>
                    <ImageUpload
                      value={newProduct.image}
                      onChange={(url) => setNewProduct((prev) => ({ ...prev, image: url }))}
                      onRemove={() => setNewProduct((prev) => ({ ...prev, image: "" }))}
                    />
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="stock">Stock Quantity</Label>
                      <Input
                        id="stock"
                        type="number"
                        value={newProduct.stock}
                        onChange={(e) => setNewProduct((prev) => ({ ...prev, stock: e.target.value }))}
                        placeholder="Leave empty for unlimited"
                      />
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={newProduct.autoOrder}
                      onCheckedChange={(checked) => setNewProduct((prev) => ({ ...prev, autoOrder: checked }))}
                    />
                    <Label>Enable Auto-Fulfillment</Label>
                  </div>

                  <Button type="submit" className="bg-black text-white hover:bg-gray-800">
                    Add Product to Store
                  </Button>
                </form>
              </CardContent>
            </Card>

            <Card className="border-2 border-gray-200">
              <CardHeader>
                <CardTitle>Product Management</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {products.map((product, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border rounded">
                      <div className="flex-1">
                        <h4 className="font-medium">{product.name}</h4>
                        <p className="text-sm text-gray-600">
                          Cost: R{product.supplierCost} | Price: R{product.price} | Profit: R
                          {(product.price - product.supplierCost).toFixed(2)}
                        </p>
                        <p className="text-xs text-gray-500">
                          Stock: {product.stock} | Status: {product.isActive ? "Active" : "Out of Stock"}
                        </p>
                      </div>
                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <ExternalLink className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline" className="text-red-600 bg-transparent">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Business Settings Tab - Keep existing */}
        {activeTab === "business" && (
          <div className="space-y-8">
            <Card className="border-2 border-green-500">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <CreditCard className="mr-2 h-5 w-5" />
                  Business Account & Payment Settings
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="businessAccount">Business Bank Account</Label>
                    <Input
                      id="businessAccount"
                      value={businessSettings.businessAccount}
                      onChange={(e) => setBusinessSettings((prev) => ({ ...prev, businessAccount: e.target.value }))}
                      placeholder="Account Number or Payment Gateway Details"
                    />
                  </div>
                  <div>
                    <Label htmlFor="notificationEmail">Notification Email</Label>
                    <Input
                      id="notificationEmail"
                      type="email"
                      value={businessSettings.notificationEmail}
                      onChange={(e) => setBusinessSettings((prev) => ({ ...prev, notificationEmail: e.target.value }))}
                      placeholder="admin@ccwearables.com"
                    />
                  </div>
                  <div>
                    <Label htmlFor="highValueThreshold">High Value Order Threshold (ZAR)</Label>
                    <Input
                      id="highValueThreshold"
                      type="number"
                      value={businessSettings.highValueThreshold}
                      onChange={(e) =>
                        setBusinessSettings((prev) => ({
                          ...prev,
                          highValueThreshold: Number.parseInt(e.target.value),
                        }))
                      }
                    />
                  </div>
                  <div>
                    <Label htmlFor="profitMargin">Default Profit Margin (%)</Label>
                    <Input
                      id="profitMargin"
                      type="number"
                      step="0.1"
                      value={businessSettings.profitMargin}
                      onChange={(e) =>
                        setBusinessSettings((prev) => ({ ...prev, profitMargin: Number.parseFloat(e.target.value) }))
                      }
                    />
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={businessSettings.autoFulfillment}
                      onCheckedChange={(checked) =>
                        setBusinessSettings((prev) => ({ ...prev, autoFulfillment: checked }))
                      }
                    />
                    <Label>Enable Automatic Order Fulfillment</Label>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}
