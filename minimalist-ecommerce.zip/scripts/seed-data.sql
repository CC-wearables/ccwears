-- Insert sample products
INSERT INTO products (name, description, price, category, image_url, stock_quantity) VALUES
('Wireless Headphones', 'Premium wireless headphones with noise cancellation', 1299.00, 'electronics', '/placeholder.svg?height=300&width=300', 50),
('Smart Watch', 'Track your fitness and stay connected', 2499.00, 'electronics', '/placeholder.svg?height=300&width=300', 30),
('Bluetooth Speaker', 'Portable speaker with premium sound quality', 899.00, 'electronics', '/placeholder.svg?height=300&width=300', 25),
('Minimalist T-Shirt', 'Clean, simple design in premium cotton', 299.00, 'clothing', '/placeholder.svg?height=300&width=300', 100),
('Black Jeans', 'Classic black denim with modern fit', 799.00, 'clothing', '/placeholder.svg?height=300&width=300', 75),
('White Sneakers', 'Minimalist white leather sneakers', 1199.00, 'clothing', '/placeholder.svg?height=300&width=300', 40),
('Custom Print Hoodie', 'Design your own custom hoodie', 599.00, 'print-on-demand', '/placeholder.svg?height=300&width=300', 0),
('Custom Poster', 'High-quality custom poster printing', 199.00, 'print-on-demand', '/placeholder.svg?height=300&width=300', 0),
('Custom Mug', 'Personalized ceramic mug', 149.00, 'print-on-demand', '/placeholder.svg?height=300&width=300', 0);

-- Insert sample admin user (password should be hashed in real implementation)
INSERT INTO users (email, first_name, last_name, password_hash, role) VALUES
('admin@minimalstore.co.za', 'Admin', 'User', '$2b$10$example_hash_here', 'admin');

-- Insert sample customer
INSERT INTO users (email, first_name, last_name, password_hash, role) VALUES
('customer@example.com', 'John', 'Doe', '$2b$10$example_hash_here', 'customer');
