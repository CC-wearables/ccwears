-- Create production_partners table
CREATE TABLE IF NOT EXISTS production_partners (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    partner_type VARCHAR(100) NOT NULL,
    api_endpoint VARCHAR(500),
    api_key VARCHAR(255),
    production_time_days INTEGER DEFAULT 3,
    shipping_time_days INTEGER DEFAULT 5,
    quality_rating INTEGER DEFAULT 5,
    specialties TEXT,
    location VARCHAR(255),
    status VARCHAR(20) DEFAULT 'active',
    auto_assign BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create custom_designs table
CREATE TABLE IF NOT EXISTS custom_designs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID REFERENCES orders(id) ON DELETE CASCADE,
    design_type VARCHAR(50) NOT NULL,
    design_data JSONB NOT NULL,
    base_product VARCHAR(100) NOT NULL,
    production_partner_id UUID REFERENCES production_partners(id),
    production_status VARCHAR(50) DEFAULT 'pending',
    production_order_id VARCHAR(255),
    tracking_number VARCHAR(255),
    estimated_delivery DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert sample production partners
INSERT INTO production_partners (name, partner_type, production_time_days, shipping_time_days, quality_rating, location, status, specialties) VALUES
('PrintHub SA', 'apparel', 2, 3, 5, 'Cape Town', 'active', 'DTG printing, embroidery, eco-friendly materials'),
('Custom Creations', 'accessories', 1, 2, 4, 'Johannesburg', 'active', 'Phone cases, bags, promotional items'),
('Print & Ship Co', 'home', 3, 4, 5, 'Durban', 'active', 'Mugs, posters, home decor items'),
('Eco Print Co', 'all', 3, 5, 4, 'Pretoria', 'pending', 'Sustainable printing, organic materials')
ON CONFLICT DO NOTHING;

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_production_partners_type ON production_partners(partner_type);
CREATE INDEX IF NOT EXISTS idx_production_partners_status ON production_partners(status);
CREATE INDEX IF NOT EXISTS idx_custom_designs_order_id ON custom_designs(order_id);
CREATE INDEX IF NOT EXISTS idx_custom_designs_status ON custom_designs(production_status);
CREATE INDEX IF NOT EXISTS idx_custom_designs_partner ON custom_designs(production_partner_id);
