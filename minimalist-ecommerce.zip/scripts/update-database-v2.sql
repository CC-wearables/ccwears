-- Add dropshipping and automation features to existing tables

-- Add supplier and automation columns to products table
ALTER TABLE products ADD COLUMN IF NOT EXISTS supplier_url VARCHAR(500);
ALTER TABLE products ADD COLUMN IF NOT EXISTS supplier_cost DECIMAL(10,2);
ALTER TABLE products ADD COLUMN IF NOT EXISTS profit_margin DECIMAL(5,2);
ALTER TABLE products ADD COLUMN IF NOT EXISTS auto_fulfill BOOLEAN DEFAULT true;
ALTER TABLE products ADD COLUMN IF NOT EXISTS supplier_id VARCHAR(100);

-- Create suppliers table
CREATE TABLE IF NOT EXISTS suppliers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    api_endpoint VARCHAR(500),
    api_key VARCHAR(255),
    status VARCHAR(20) DEFAULT 'active',
    auto_sync BOOLEAN DEFAULT false,
    sync_interval INTEGER DEFAULT 24,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create business_settings table
CREATE TABLE IF NOT EXISTS business_settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create notifications table
CREATE TABLE IF NOT EXISTS notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    type VARCHAR(50) NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT false,
    metadata JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create order_fulfillment table for tracking automated orders
CREATE TABLE IF NOT EXISTS order_fulfillment (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID REFERENCES orders(id) ON DELETE CASCADE,
    supplier_order_id VARCHAR(255),
    fulfillment_status VARCHAR(50) DEFAULT 'pending',
    tracking_number VARCHAR(255),
    supplier_cost DECIMAL(10,2),
    profit_amount DECIMAL(10,2),
    auto_processed BOOLEAN DEFAULT false,
    processed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default business settings
INSERT INTO business_settings (setting_key, setting_value) VALUES
('business_account', ''),
('notification_email', 'admin@ccwearables.com'),
('high_value_threshold', '5000'),
('auto_fulfillment', 'true'),
('default_profit_margin', '16.67')
ON CONFLICT (setting_key) DO NOTHING;

-- Insert sample suppliers
INSERT INTO suppliers (name, status) VALUES
('TechHub SA', 'connected'),
('Wearable World', 'pending'),
('Fashion Forward', 'disconnected'),
('Electronics Plus', 'connected')
ON CONFLICT DO NOTHING;

-- Create indexes for new tables
CREATE INDEX IF NOT EXISTS idx_suppliers_status ON suppliers(status);
CREATE INDEX IF NOT EXISTS idx_notifications_type ON notifications(type);
CREATE INDEX IF NOT EXISTS idx_notifications_read ON notifications(is_read);
CREATE INDEX IF NOT EXISTS idx_order_fulfillment_order_id ON order_fulfillment(order_id);
CREATE INDEX IF NOT EXISTS idx_order_fulfillment_status ON order_fulfillment(fulfillment_status);
CREATE INDEX IF NOT EXISTS idx_business_settings_key ON business_settings(setting_key);
